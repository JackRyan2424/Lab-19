from pathlib import Path
import json
import re
import sys
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "buffett_skill"
sys.path.insert(0, str(SKILL / "scripts"))
from edgar import fetch, table, METRICS, numeric, unsupported_numbers
from panel import evaluate, audit, binding, INVESTORS, SLUGS
from build_panel_submission import METHOD, DISCUSSION
from expert_format import source_path, source_url, claim_values, provenance as expert_provenance

OUTPUT = Path(__file__).resolve().parent / "output"
OUTPUT.mkdir(exist_ok=True)
st.set_page_config(page_title="QQQ investor skill app", layout="wide")
st.title("QQQ investor skill app")
st.markdown('**Fund: Invesco QQQ · Selected company: Apple (AAPL)**')
st.markdown('Largest holding on the [Invesco list dated November 3, 2026](https://www.invesco.com/qqq-etf/en/about.html): Apple, 8.13%. Apple files annual reports on EDGAR; no fallback is needed.')
if 'company_ticker' not in st.session_state:
    st.session_state['company_ticker'] = 'AAPL'
left, right = st.columns(2)
if left.button('QQQ company: AAPL'):
    st.session_state['company_ticker'] = 'AAPL'
if right.button('Known-answer check: COST'):
    st.session_state['company_ticker'] = 'COST'
st.caption("data from SEC EDGAR; built with AI help, a learning demonstration, not investment advice.")
with st.expander("What is a skill, and how does it work?"):
    st.markdown("""
**What is a skill?**

A skill is a folder containing a `SKILL.md` instruction file and optional scripts.
Our Buffett skill tells the AI how to retrieve SEC data, run consistent calculations,
and write a memo.

**Why does the AI read only the name and description first?**

The AI uses the name and description to decide whether the skill matches your request.
It loads the full instructions and supporting files only when needed. This saves
context space and keeps unrelated instructions from distracting it.

**Why do the numbers belong in code?**

Code applies the same data-selection rules, formulas, and checks each time, making
the results reproducible and traceable to SEC filings. The AI interprets those
results and explains their limits. Code computes; the model judges.
""")
with st.form("company"):
    ticker = st.text_input("Ticker", key='company_ticker').strip().upper()
    contact_name = st.text_input("Name", "Jack Ryan")
    contact_email = st.text_input("Email", "ryan307@purdue.edu")
    user_agent = f"{contact_name.strip()} {contact_email.strip()}"
    refresh = st.form_submit_button("Download latest SEC facts")
    st.form_submit_button("View saved report")
if not re.fullmatch(r"[A-Z][A-Z0-9.-]{0,14}", ticker):
    st.error("Enter a valid ticker.")
    st.stop()

@st.cache_data(ttl=3600, max_entries=20)
def load_sec(symbol, agent):
    return fetch(symbol, agent, OUTPUT)

if refresh:
    try:
        load_sec.clear()
        with st.spinner("Reading SEC EDGAR…"):
            load_sec(ticker, user_agent)
    except Exception as exc:
        st.error(f"SEC download failed: {exc}")
        st.stop()
report_path = OUTPUT / f"{ticker}-report.json"
if not report_path.exists():
    st.info("Enter your name and email, then download SEC facts. No estimates or substitute data are used.")
    st.stop()
report = json.loads(report_path.read_text(encoding="utf-8"))
st.subheader(report["company"])
st.caption(f"Saved SEC snapshot retrieved {report['retrieved_at']}. Download to refresh. USD millions unless indicated.")
chart = pd.DataFrame([{ "Fiscal year end": r["fiscal_year_end"],
    **{m.replace("_", " ").title(): r[m]["value"] / 1_000_000 if numeric(r[m]["value"]) else None
       for m in ("owner_earnings", "net_income")}} for r in report["rows"]])
st.line_chart(chart, x="Fiscal year end", y=["Owner Earnings", "Net Income"], y_label="USD millions", alt="Owner earnings and net income by fiscal-year-end date")
st.dataframe(pd.DataFrame(table(report)), hide_index=True, alt="Annual financial metrics; missing values remain explicit")
st.subheader("Buffett’s checks")
st.table(pd.DataFrame(report["checks"].items(), columns=["Check", "Result"]), hide_index=True, alt="Three code-computed Buffett checks")
with st.expander("XBRL tags and filing provenance"):
    provenance = [{"Fiscal year end": r["fiscal_year_end"], "Metric": m, **r[m]} for r in report["rows"] for m in METRICS]
    st.dataframe(pd.DataFrame(provenance).astype(str), hide_index=True, alt="Selected tags, periods, filing dates and accession numbers")
st.caption("Owner earnings = operating cash flow − capital spending. ROE uses year-end equity. These checks do not establish moat, management quality or a fair stock price.")
st.subheader("Panel on the same facts")
st.caption('Investor analyses use the original FAskills field structure. Unsupported forecasts, scores, valuations and holdings remain not known. These are saved AI-authored analyses, not live investor opinions.')
panel = evaluate(report)
st.table(pd.DataFrame(panel['checks']), hide_index=True, alt="Investor by check, with pass, fail or not known")
st.caption(f"Revenue growth a year: {panel['growth_display']}. Latest liabilities/equity: {panel['leverage_display']}.")
probe = evaluate(report, .05)
st.write(f"Threshold probe: at 15%, growth {panel['checks'][3]['Result']}; at 5%, growth {probe['checks'][3]['Result']}. R&D remains {probe['checks'][4]['Result']}.")
st.caption("Baseline retained: 15%, to preserve a high-growth screen rather than fit the example. The probe changes the rule, not the company.")
all_flags = []
panel_memos = []
for column, investor, slug in zip(st.columns(3), INVESTORS, SLUGS):
    with column:
        st.subheader(investor)
        mp = OUTPUT / f'{ticker}-{slug}-memo.md'
        sp = OUTPUT / f'{ticker}-{slug}-memo-source.txt'
        saved_panel = mp.read_text(encoding='utf-8') if mp.exists() else ''
        if saved_panel and (not sp.exists() or sp.read_text().strip() != binding(report)):
            st.warning('Memo needs review against the current facts or rules.')
        if not saved_panel:
            st.info('No authored memo yet. Run the investor skill on the printed report.')
        edited = st.text_area(f'{investor} memo', saved_panel, height=280, key=f'panel-{ticker}-{slug}-{binding(report)}')
        st.markdown(edited)
        found = audit(edited, report)
        all_flags.extend([{'Investor': investor, **flag} for flag in found])
        json_path = OUTPUT / f'{ticker}-{slug}-analysis.json'
        if json_path.exists():
            structured = json.loads(json_path.read_text(encoding='utf-8'))
            structured_flags = audit(claim_values(structured), report)
            all_flags.extend([{'Investor': investor + ' JSON', **flag} for flag in structured_flags])
            with st.expander(f'{investor}: original-format analysis'):
                st.caption('Original field names and nesting are retained. Unsupported field values are not known, including fields the upstream template normally expects to be numeric or boolean. Memo edits do not rewrite this saved JSON.')
                st.json(structured, expanded=False)
                st.download_button(f'Download {investor} JSON', json_path.read_text(encoding='utf-8'), file_name=json_path.name, mime='application/json')
            metadata_path = OUTPUT / f'{ticker}-{slug}-format-source.json'
            if not metadata_path.exists():
                st.warning('Structured analysis has no source binding; review required.')
            else:
                metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
                if metadata.get('report_binding') != binding(report) or metadata.get('sha256') != expert_provenance(slug)['sha256']:
                    st.warning('Structured analysis needs review against the current facts or source format.')
        with st.expander(f'{investor}: FAskills source file'):
            st.markdown(f'[Original investor file]({source_url(slug)})')
            st.download_button(f'Download {investor} original file', source_path(slug).read_text(encoding='utf-8'), file_name=slug+'-faskills-original.md')
            st.code(source_path(slug).read_text(encoding='utf-8'), language='markdown')
        panel_memos.append((mp, edited))
        if slug == 'cathie-wood':
            st.caption('Kept 15%: the screen is intended to identify high growth; lowering the hurdle to fit COST would change its purpose.')
if all_flags:
    st.error('Unprinted-number flag across all panel memos')
    st.table(pd.DataFrame(all_flags), hide_index=True, alt='Unsupported numbers by investor and line')
else:
    st.success('Panel number audit: no unsupported numeric tokens. Presence does not prove correct meaning; missing memos and stale sources require review.')
if st.button('Save panel memo edits'):
    for mp, edited in panel_memos:
        mp.write_text(edited, encoding='utf-8')
    st.success('Saved edits. Source bindings are only renewed after evidence review.')
st.download_button('Download panel memos', '\n\n---\n\n'.join(m for _,m in panel_memos), file_name=f'{ticker}-panel-memos.md')
st.subheader('Interpretation and my decision')
st.markdown(DISCUSSION)
with st.expander('Method and the three skill files'):
    st.markdown(METHOD)
    for label, path in [('Buffett', ROOT/'buffett_skill'/'SKILL.md'), ('Cathie Wood', ROOT/'cathie-wood-edgar'/'SKILL.md'), ('Burry', ROOT/'burry-edgar'/'SKILL.md')]:
        st.download_button(f'Download {label} skill', path.read_text(encoding='utf-8'), file_name=f'{path.parent.name}-SKILL.md')
submission = Path(__file__).parent / 'Investor-Panel-Submission.md'
if submission.exists():
    st.download_button('Download complete written submission', submission.read_text(encoding='utf-8'), file_name=submission.name)
st.subheader("AI memo — Buffett-inspired simulation")
memo_path = OUTPUT / f"{ticker}-memo.md"
source_path = OUTPUT / f"{ticker}-memo-source.txt"
saved = memo_path.read_text(encoding="utf-8") if memo_path.exists() else ""
if saved and (not source_path.exists() or source_path.read_text().strip() != report["facts_sha256"]):
    st.warning("This memo is not bound to the current SEC snapshot. Ask the AI to review it using the skill.")
if not saved:
    st.info(f"Ask your AI: Use $buffett-edgar on {ticker}, read its printed report, and save the memo.")
memo = st.text_area("Memo editor — try adding 40.0%", saved, height=220, key=f"memo-{ticker}-{report['facts_sha256']}")
flags = unsupported_numbers(memo, report)
if flags:
    st.error("Numbers the script did not print: " + "; ".join(f"{f['number']} (line {f['line']})" for f in flags))
elif memo:
    st.success("Every numeric token appears in the script’s displayed financial output. This checks presence, not meaning.")
st.markdown(memo)
decision_path = OUTPUT / f"{ticker}-decision.md"
decision = st.text_input("Your decision: Do you trust the verdict, and why?", decision_path.read_text(encoding="utf-8") if decision_path.exists() else "", key=f"decision-{ticker}")
if st.button("Save memo and my decision"):
    memo_path.write_text(memo, encoding="utf-8")
    decision_path.write_text(decision, encoding="utf-8")
    st.success("Saved. Any unsupported numbers remain flagged above.")
st.download_button("Download memo", memo + "\n\nMy decision: " + decision, file_name=f"{ticker}-memo.md", mime="text/markdown")
