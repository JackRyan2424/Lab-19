# Investor panel — individual submission

Jack Ryan

## Method

The panel uses a single saved SEC Company Facts snapshot for each company. COST uses the saved classroom snapshot; AAPL was downloaded from SEC on November 5, 2026 and saved for reproducibility. Only annual 10-K facts qualify; fiscal dates come from annual periods, and the latest filing wins within each preferred tag. The original revenue, cash flow, capital spending, equity, ROE and owner-earnings rules are preserved. Liabilities and ResearchAndDevelopmentExpense are the added source tags. No missing values are replaced with estimates or zero.

ROE = net income / year-end equity. Owner earnings = operating cash flow - capital spending, a classroom proxy rather than maintenance-capital-expenditure analysis. Revenue growth a year = (last revenue / first revenue)^(1/4) - 1. R&D intensity = ResearchAndDevelopmentExpense / revenue. Liabilities/equity = Liabilities / StockholdersEquity. A ratio with missing inputs or a nonpositive denominator is not known; a missing raw fact is not found. Comparisons use unrounded values.

The skills adapt FAskills' business-quality, innovation and accounting-quality lenses to the assignment's narrow checks. They are AI simulations, not authentic statements or a complete implementation of those investors' methods. Code computes the evidence; separately authored memos interpret it. Their agreement is not independent confirmation because all read the same data and share its omissions. The number audit checks printed numeric tokens and units, not whether a claim uses the right metric; the metric associations were also reviewed.

## COST — COSTCO WHOLESALE CORP /NEW

Revenue growth a year: 7.51%. Saved snapshot retrieved 2026-11-03T21:49:02.061769+00:00.

| FY end | R&D expense (USD millions) | R&D / revenue | Liabilities / equity |
| --- | --- | --- | --- |
| 2022-08-28 | not found | not known | 2.108 |
| 2023-09-03 | not found | not known | 1.753 |
| 2024-09-01 | not found | not known | 1.956 |
| 2025-08-31 | not found | not known | 1.644 |
| 2026-08-30 | not found | not known | 1.487 |

| Investor | Check | Result |
| --- | --- | --- |
| Buffett | ROE of 15% or more every year | pass |
| Buffett | Owner earnings positive every year | pass |
| Buffett | Owner earnings grew, first year to last | pass |
| Cathie Wood | Revenue growth at least 15% a year, first to last | fail |
| Cathie Wood | R&D at least 5% of revenue, latest year | not known |
| Burry | Operating cash flow at least net income every year | pass |
| Burry | Liabilities no more than twice equity, latest year | pass |

# Buffett: own the business

AI simulation; not an authentic investor statement. Signal describes business-screen fit, not an expected stock return.

## Thesis

I would own the business on this business-quality screen. ROE clears the hurdle every year, owner earnings are positive throughout, and owner earnings rise from $3,501 million to $9,382 million. The cash evidence supports a profitable business with room to reinvest. It does not establish a durable moat, management quality, or an attractive purchase price; those require further work.

## Forward outlook

Not known. No forecast, timeline, catalyst or price target is established by this screen.

## Analysis

### Circle of competence

I understand the accounting checks, but the printed financial series does not establish a complete understanding of the business.

### Moat analysis

High returns are a useful starting point. I cannot infer pricing power, customer loyalty or the durability of a moat from these ratios alone.

### Management quality

not known: management incentives, acquisitions and capital-allocation decisions were not assessed in the printed evidence.

### Owner earnings

I would own the business on this business-quality screen. ROE clears the hurdle every year, owner earnings are positive throughout, and owner earnings rise from $3,501 million to $9,382 million. The cash evidence supports a profitable business with room to reinvest. It does not establish a durable moat, management quality, or an attractive purchase price; those require further work. The assignment uses operating cash flow minus capital spending; this is not the source template's maintenance-capital estimate or a per-share calculation.

### Intrinsic value

not known: no valuation model or forecasts are included.

### Margin of safety

not known: neither a market price nor an intrinsic-value estimate is included.

## Key risks

- A profitable history may not establish a durable competitive advantage.
- Capital-spending totals do not separate maintenance and expansion needs.
- A business-quality endorsement may still correspond to an unattractive stock price.

## What changes my mind

- Evidence of weakening cash generation or returns.
- A filing review that identifies a weakening competitive position or poor capital allocation.

## Holdings context

Not known: actual investor holdings and recent trades were not collected.

## Price levels

Buy and sell levels: not known. No valuation is included.

## Private assessment

I like the printed cash evidence. I would not mistake these screening results for a completed investigation or a price at which to buy.

Confidence and qualitative scores: not known; no unsupported scores are assigned.


# Cathie Wood: pass

AI simulation; not an authentic investor statement. Signal describes business-screen fit, not an expected stock return.

## Thesis

I would pass under this growth-and-innovation screen. Revenue growth of 7.51% falls below the 15% hurdle. ResearchAndDevelopmentExpense is not found, so the R&D check is not known; missing disclosure is not evidence of no innovation. The results do not establish disruptive technology or future market expansion. A sound cash-generating business can still fall outside this particular screen.

## Forward outlook

Not known. No forecast, timeline, catalyst or price target is established by this screen.

## Analysis

### Disruption assessment

not known: R&D spending and historical revenue do not establish whether the business is a disruptor, enabler or incumbent at risk.

### Tam expansion

not known: addressable-market estimates and adoption evidence are not in the shared facts.

### Wrights law analysis

not known: unit-cost and cumulative-production observations are absent.

### Innovation trajectory

R&D intensity: not known.

I would pass under this growth-and-innovation screen. Revenue growth of 7.51% falls below the 15% hurdle. ResearchAndDevelopmentExpense is not found, so the R&D check is not known; missing disclosure is not evidence of no innovation. The results do not establish disruptive technology or future market expansion. A sound cash-generating business can still fall outside this particular screen.

### Five year model

Not known: the required evidence or model is not included.

### Convergence opportunity

not known: the annual totals do not establish participation in converging technology platforms.

## Key risks

- Research spending may not translate into successful innovation.
- Historical growth may not persist or accelerate.
- A growth cutoff can exclude a sound business that does not fit this lens.

## What changes my mind

- Printed growth evidence that clears the retained hurdle.
- Documented research productivity and adoption evidence that supports an innovation thesis.

## Holdings context

Not known: actual investor holdings and recent trades were not collected.

## Price levels

Buy and sell levels: not known. No valuation is included.

## Private assessment

An innovation narrative needs evidence beyond spending. I cannot supply an addressable market, cost curve or future price from the annual facts alone.

Confidence and qualitative scores: not known; no unsupported scores are assigned.

Threshold kept: 15%, because this lens is intended to identify high growth rather than fit the example.


# Burry: watch it

AI simulation; not an authentic investor statement. Signal describes business-screen fit, not an expected stock return.

## Thesis

I would watch it. Operating cash flow covers net income in every selected year, and latest liabilities/equity is 1.49, below the ceiling of 2. These checks support cash backing and a manageable balance sheet under the classroom rule. I still need to examine footnotes, obligations and the sustainability of cash generation. Passing these ratios does not prove the absence of accounting risk or establish an attractive price.

## Forward outlook

Not known. No forecast, timeline, catalyst or price target is established by this screen.

## Analysis

### Revenue quality

not known: the shared printed evidence does not establish this assessment.

### Earnings quality

I would watch it. Operating cash flow covers net income in every selected year, and latest liabilities/equity is 1.49, below the ceiling of 2. These checks support cash backing and a manageable balance sheet under the classroom rule. I still need to examine footnotes, obligations and the sustainability of cash generation. Passing these ratios does not prove the absence of accounting risk or establish an attractive price.

### Balance sheet forensics

Latest liabilities/equity is 1.49. This is a reported ratio, not a finding about hidden liabilities, covenant headroom or asset impairment.

### Bear case

These are risks to investigate, not established misconduct or a quantified downside scenario.

### Contrarian signal

not known: consensus expectations and market prices were not collected; no long or short trade is inferred.

### Sec filing findings

Findings come from selected annual XBRL facts. Footnotes, risk-factor text, insider trades and audit opinions were not reviewed.

## Key risks

- Cash flow and earnings can diverge because of timing as well as economic weakness.
- A liabilities/equity cutoff does not distinguish every type of obligation.
- A failed screen does not establish fraud or mispricing.

## What changes my mind

- A filing-based explanation of cash conversion and the obligations behind the balance sheet.
- Sustained cash backing and a balance sheet that meets the retained rule.

## Holdings context

Not known: actual investor holdings and recent trades were not collected.

## Price levels

Buy and sell levels: not known. No valuation is included.

## Private assessment

I would investigate the gaps before acting. The shared figures cannot tell me whether the market is wrong, and I will not invent an accounting allegation.

Confidence and qualitative scores: not known; no unsupported scores are assigned.


Number audit: all investor memos passed. See the verification file for injected-number tests.

[Full printed evidence](output/COST-panel-numbers.md)

[SEC Company Facts](https://data.sec.gov/api/xbrl/companyfacts/CIK0000909832.json)

## AAPL — Apple Inc.

Revenue growth a year: 4.97%. Saved snapshot retrieved 2026-11-05T22:01:47.184993+00:00.

| FY end | R&D expense (USD millions) | R&D / revenue | Liabilities / equity |
| --- | --- | --- | --- |
| 2022-09-24 | 26,251 | 6.66% | 5.962 |
| 2023-09-30 | 29,915 | 7.80% | 4.673 |
| 2024-09-28 | 31,370 | 8.02% | 5.409 |
| 2025-09-27 | 34,550 | 8.30% | 3.872 |
| 2026-09-26 | 45,765 | 9.56% | 2.609 |

| Investor | Check | Result |
| --- | --- | --- |
| Buffett | ROE of 15% or more every year | pass |
| Buffett | Owner earnings positive every year | pass |
| Buffett | Owner earnings grew, first year to last | pass |
| Cathie Wood | Revenue growth at least 15% a year, first to last | fail |
| Cathie Wood | R&D at least 5% of revenue, latest year | pass |
| Burry | Operating cash flow at least net income every year | fail |
| Burry | Liabilities no more than twice equity, latest year | fail |

# Buffett: own the business

AI simulation; not an authentic investor statement. Signal describes business-screen fit, not an expected stock return.

## Thesis

I would own the business on this business-quality screen. ROE exceeds 15% every year, owner earnings remain positive, and owner earnings grow from 111,443 million USD to 136,056 million USD. Growth is first-to-last, not uninterrupted: owner earnings fall in some intervening years. Strong cash generation supports the business case, but unusually high ROE needs interpretation alongside the equity base. These checks do not prove a durable moat, sound management or an attractive stock price.

## Forward outlook

Not known. No forecast, timeline, catalyst or price target is established by this screen.

## Analysis

### Circle of competence

I understand the accounting checks, but the printed financial series does not establish a complete understanding of the business.

### Moat analysis

High returns are a useful starting point. I cannot infer pricing power, customer loyalty or the durability of a moat from these ratios alone.

### Management quality

not known: management incentives, acquisitions and capital-allocation decisions were not assessed in the printed evidence.

### Owner earnings

I would own the business on this business-quality screen. ROE exceeds 15% every year, owner earnings remain positive, and owner earnings grow from 111,443 million USD to 136,056 million USD. Growth is first-to-last, not uninterrupted: owner earnings fall in some intervening years. Strong cash generation supports the business case, but unusually high ROE needs interpretation alongside the equity base. These checks do not prove a durable moat, sound management or an attractive stock price. The assignment uses operating cash flow minus capital spending; this is not the source template's maintenance-capital estimate or a per-share calculation.

### Intrinsic value

not known: no valuation model or forecasts are included.

### Margin of safety

not known: neither a market price nor an intrinsic-value estimate is included.

## Key risks

- A profitable history may not establish a durable competitive advantage.
- Capital-spending totals do not separate maintenance and expansion needs.
- A business-quality endorsement may still correspond to an unattractive stock price.

## What changes my mind

- Evidence of weakening cash generation or returns.
- A filing review that identifies a weakening competitive position or poor capital allocation.

## Holdings context

Not known: actual investor holdings and recent trades were not collected.

## Price levels

Buy and sell levels: not known. No valuation is included.

## Private assessment

I like the printed cash evidence. I would not mistake these screening results for a completed investigation or a price at which to buy.

Confidence and qualitative scores: not known; no unsupported scores are assigned.


# Cathie Wood: pass

AI simulation; not an authentic investor statement. Signal describes business-screen fit, not an expected stock return.

## Thesis

I would pass under this high-growth screen. Revenue growth of 4.97% is below the 15% hurdle. Latest R&D intensity of 9.56% passes the 5% test, so the result is mixed: research investment is visible, but historical revenue growth does not meet the chosen standard. R&D spending alone cannot prove successful innovation or future growth. I would require more evidence before treating the company as a disruptive-growth investment.

## Forward outlook

Not known. No forecast, timeline, catalyst or price target is established by this screen.

## Analysis

### Disruption assessment

not known: R&D spending and historical revenue do not establish whether the business is a disruptor, enabler or incumbent at risk.

### Tam expansion

not known: addressable-market estimates and adoption evidence are not in the shared facts.

### Wrights law analysis

not known: unit-cost and cumulative-production observations are absent.

### Innovation trajectory

R&D intensity: 9.56%.

I would pass under this high-growth screen. Revenue growth of 4.97% is below the 15% hurdle. Latest R&D intensity of 9.56% passes the 5% test, so the result is mixed: research investment is visible, but historical revenue growth does not meet the chosen standard. R&D spending alone cannot prove successful innovation or future growth. I would require more evidence before treating the company as a disruptive-growth investment.

### Five year model

Not known: the required evidence or model is not included.

### Convergence opportunity

not known: the annual totals do not establish participation in converging technology platforms.

## Key risks

- Research spending may not translate into successful innovation.
- Historical growth may not persist or accelerate.
- A growth cutoff can exclude a sound business that does not fit this lens.

## What changes my mind

- Printed growth evidence that clears the retained hurdle.
- Documented research productivity and adoption evidence that supports an innovation thesis.

## Holdings context

Not known: actual investor holdings and recent trades were not collected.

## Price levels

Buy and sell levels: not known. No valuation is included.

## Private assessment

An innovation narrative needs evidence beyond spending. I cannot supply an addressable market, cost curve or future price from the annual facts alone.

Confidence and qualitative scores: not known; no unsupported scores are assigned.

Threshold kept: 15%, because this lens is intended to identify high growth rather than fit the example.


# Burry: pass

AI simulation; not an authentic investor statement. Signal describes business-screen fit, not an expected stock return.

## Thesis

I would pass under these classroom rules. On 2025-09-27, operating cash flow of 111,482 million USD is below net income of 112,010 million USD, so the every-year cash-backing check fails despite stronger latest cash flow. Latest liabilities/equity is 2.61, above the ceiling of 2. I would investigate working-capital timing and the composition of liabilities and equity. These failed checks are research flags, not proof of manipulation or insolvency.

## Forward outlook

Not known. No forecast, timeline, catalyst or price target is established by this screen.

## Analysis

### Revenue quality

not known: the shared printed evidence does not establish this assessment.

### Earnings quality

I would pass under these classroom rules. On 2025-09-27, operating cash flow of 111,482 million USD is below net income of 112,010 million USD, so the every-year cash-backing check fails despite stronger latest cash flow. Latest liabilities/equity is 2.61, above the ceiling of 2. I would investigate working-capital timing and the composition of liabilities and equity. These failed checks are research flags, not proof of manipulation or insolvency.

### Balance sheet forensics

Latest liabilities/equity is 2.61. This is a reported ratio, not a finding about hidden liabilities, covenant headroom or asset impairment.

### Bear case

These are risks to investigate, not established misconduct or a quantified downside scenario.

### Contrarian signal

not known: consensus expectations and market prices were not collected; no long or short trade is inferred.

### Sec filing findings

Findings come from selected annual XBRL facts. Footnotes, risk-factor text, insider trades and audit opinions were not reviewed.

## Key risks

- Cash flow and earnings can diverge because of timing as well as economic weakness.
- A liabilities/equity cutoff does not distinguish every type of obligation.
- A failed screen does not establish fraud or mispricing.

## What changes my mind

- A filing-based explanation of cash conversion and the obligations behind the balance sheet.
- Sustained cash backing and a balance sheet that meets the retained rule.

## Holdings context

Not known: actual investor holdings and recent trades were not collected.

## Price levels

Buy and sell levels: not known. No valuation is included.

## Private assessment

I would investigate the gaps before acting. The shared figures cannot tell me whether the market is wrong, and I will not invent an accounting allegation.

Confidence and qualitative scores: not known; no unsupported scores are assigned.


Number audit: all investor memos passed. See the verification file for injected-number tests.

[Full printed evidence](output/AAPL-panel-numbers.md)

[SEC Company Facts](https://data.sec.gov/api/xbrl/companyfacts/CIK0000320193.json)

## Interpretation and decision

Company selection: My fund is Invesco QQQ. Invesco's holdings list dated November 3, 2026 ranks Apple (AAPL) first at 8.13%, ahead of NVIDIA at 8.02%. Apple files annual reports on EDGAR, so no fallback company is needed. This selection uses the dated issuer list rather than conflicting third-party summaries.

Agreement and split: On COST, Buffett is favorable, Burry's checks pass but his memo calls for further investigation, and Cathie Wood rejects the growth fit. On AAPL, Buffett passes every check and gives a favorable business-quality verdict. Cathie Wood passes on the investment because growth fails even though R&D passes. Burry passes because both cash backing and liabilities/equity fail. They agree on the facts, but emphasize different evidence. Positive owner earnings and cash flow below net income in one year can both be true. All agree that the screen cannot establish a fair stock price.

Bull case for AAPL: ROE clears the hurdle every year, owner earnings remain positive and finish above their starting value, and latest R&D intensity passes. This supports a profitable business that generates cash while investing in research. A durable competitive advantage and productive future research remain hypotheses requiring further evidence.

Bear case for AAPL: Historical growth misses the chosen hurdle, operating cash flow falls below net income in a selected year, and latest liabilities exceed twice equity. Cash conversion and capital structure need review. High ROE can reflect a small equity base as well as operating strength; the panel alone does not establish the cause. R&D spending does not guarantee successful products. All required source inputs are found for AAPL; COST's missing R&D stays explicit.

Threshold probe: COST's growth result changes from fail at 15% to pass at 5%, while R&D stays not known. AAPL's 4.97% growth fails at both thresholds; its R&D check passes in both cases. The same facts can produce different labels when the analyst changes the cutoff. A changed growth check does not automatically change an authored investment verdict.

My decision: I would trust the panel for initial screening, but only if missing data stay explicit and I review industry differences and valuation before investing.

## Sources

- [QQQ holdings — Invesco](https://www.invesco.com/qqq-etf/en/about.html)

- [Cathie Wood — FAskills](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/cathie_wood.md)

- [Burry — FAskills](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/michael_burry.md)

- [Buffett — FAskills](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md)

- [SEC API documentation](https://www.sec.gov/search-filings/edgar-application-programming-interfaces)

- [Streamlit documentation](https://docs.streamlit.io/)