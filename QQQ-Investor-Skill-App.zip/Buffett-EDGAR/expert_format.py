"""Use the pinned FAskills output field structure with honest classroom gaps."""
import hashlib
import json
import re
from panel import ROOT, audit, table, evaluate

SOURCES = {
    'buffett': ('buffett_skill', 'warren_buffett'),
    'cathie-wood': ('cathie-wood-edgar', 'cathie_wood'),
    'burry': ('burry-edgar', 'michael_burry'),
}

def source_path(slug):
    return ROOT / SOURCES[slug][0] / 'references' / 'faskills-source.md'

def source_url(slug):
    return 'https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/' + SOURCES[slug][1] + '.md'

def empty_structure(slug):
    """Extract keys from upstream's illustrative JSON, preserving every field."""
    source = source_path(slug).read_text(encoding='utf-8')
    template = source.split('## Required Output Format', 1)[1].split('```json', 1)[1].split('```', 1)[0]
    # Preserve key strings; replace example values and pseudo-JSON placeholders.
    template = re.sub(r'"(?:\\.|[^"\\])*"', lambda m: m.group() if template[m.end():].lstrip().startswith(':') else '"not known"', template)
    template = re.sub(r'<[^>]*>', '"not known"', template)
    template = re.sub(r'"not known"(?:\s*\|\s*"not known")+', '"not known"', template)
    template = re.sub(r'true\s*\|\s*false', '"not known"', template)
    result = json.loads(template)
    def clear(value):
        if isinstance(value, dict):
            return {k: clear(v) for k,v in value.items()}
        if isinstance(value, list):
            return ['not known']
        return 'not known'
    return clear(result)

def claim_values(value):
    """Audit claims, not numeric characters in upstream field names."""
    if isinstance(value, dict):
        return '\n'.join(claim_values(v) for v in value.values())
    if isinstance(value, list):
        return '\n'.join(claim_values(v) for v in value)
    return str(value)

def structure(report, slug, verdict, thesis):
    data = empty_structure(slug)
    data['expert'] = SOURCES[slug][1]
    data['signal'] = {'own the business':'bullish', 'watch it':'neutral', 'pass':'bearish'}[verdict]
    data['thesis'] = thesis
    data['forward_outlook']['prediction'] = 'not known: historical checks do not establish a forecast.'
    data['forward_outlook']['price_target'] = 'not known: prices and valuation are outside this classroom screen.'
    for section in data['analysis'].values():
        if 'reasoning' in section:
            section['reasoning'] = 'not known: the shared printed evidence does not establish this assessment.'
    a = data['analysis']
    if slug == 'buffett':
        a['circle_of_competence']['reasoning'] = 'I understand the accounting checks, but the printed financial series does not establish a complete understanding of the business.'
        a['moat_analysis']['reasoning'] = 'High returns are a useful starting point. I cannot infer pricing power, customer loyalty or the durability of a moat from these ratios alone.'
        a['management_quality']['reasoning'] = 'not known: management incentives, acquisitions and capital-allocation decisions were not assessed in the printed evidence.'
        a['owner_earnings']['reasoning'] = thesis + ' The assignment uses operating cash flow minus capital spending; this is not the source template\'s maintenance-capital estimate or a per-share calculation.'
        a['intrinsic_value']['methodology'] = 'not known: no valuation model or forecasts are included.'
        a['margin_of_safety']['reasoning'] = 'not known: neither a market price nor an intrinsic-value estimate is included.'
        data['key_risks'] = ['A profitable history may not establish a durable competitive advantage.', 'Capital-spending totals do not separate maintenance and expansion needs.', 'A business-quality endorsement may still correspond to an unattractive stock price.']
        data['what_changes_my_mind'] = ['Evidence of weakening cash generation or returns.', 'A filing review that identifies a weakening competitive position or poor capital allocation.']
        data['private_assessment'] = 'I like the printed cash evidence. I would not mistake these screening results for a completed investigation or a price at which to buy.'
    elif slug == 'cathie-wood':
        a['innovation_trajectory']['rd_intensity'] = table(report)[-1]['rd_to_revenue']
        a['innovation_trajectory']['reasoning'] = thesis
        a['disruption_assessment']['reasoning'] = 'not known: R&D spending and historical revenue do not establish whether the business is a disruptor, enabler or incumbent at risk.'
        a['tam_expansion']['reasoning'] = 'not known: addressable-market estimates and adoption evidence are not in the shared facts.'
        a['wrights_law_analysis']['reasoning'] = 'not known: unit-cost and cumulative-production observations are absent.'
        a['convergence_opportunity']['reasoning'] = 'not known: the annual totals do not establish participation in converging technology platforms.'
        data['key_risks'] = ['Research spending may not translate into successful innovation.', 'Historical growth may not persist or accelerate.', 'A growth cutoff can exclude a sound business that does not fit this lens.']
        data['what_changes_my_mind'] = ['Printed growth evidence that clears the retained hurdle.', 'Documented research productivity and adoption evidence that supports an innovation thesis.']
        data['private_assessment'] = 'An innovation narrative needs evidence beyond spending. I cannot supply an addressable market, cost curve or future price from the annual facts alone.'
    else:
        cash_check = evaluate(report)['checks'][5]['Result']
        a['earnings_quality']['ocf_vs_net_income'] = {'pass': 'OCF >= NI every selected year', 'fail': 'OCF < NI in a selected year', 'not known': 'not known'}[cash_check]
        a['earnings_quality']['reasoning'] = thesis
        a['earnings_quality']['red_flags'] = [{'fail': 'Every-year cash-backing check fails; investigate timing and sustainability.', 'pass': 'No failure on the cash-backing check; broader accounting risks are not assessed.', 'not known': 'not known: missing inputs prevent the cash-backing check.'}[cash_check]]
        a['balance_sheet_forensics']['reasoning'] = 'Latest liabilities/equity is ' + evaluate(report)['leverage_display'] + '. This is a reported ratio, not a finding about hidden liabilities, covenant headroom or asset impairment.'
        a['bear_case']['business_risk'] = 'Hypothesis: weakening cash generation could undermine the favorable business-quality case.'
        a['bear_case']['financial_risk'] = 'Hypothesis: obligations or cash-conversion problems could matter more than reported profits suggest.'
        a['bear_case']['reasoning'] = 'These are risks to investigate, not established misconduct or a quantified downside scenario.'
        a['contrarian_signal']['reasoning'] = 'not known: consensus expectations and market prices were not collected; no long or short trade is inferred.'
        a['sec_filing_findings']['key_finding_1'] = a['earnings_quality']['ocf_vs_net_income']
        a['sec_filing_findings']['key_finding_2'] = a['balance_sheet_forensics']['reasoning']
        a['sec_filing_findings']['reasoning'] = 'Findings come from selected annual XBRL facts. Footnotes, risk-factor text, insider trades and audit opinions were not reviewed.'
        data['key_risks'] = ['Cash flow and earnings can diverge because of timing as well as economic weakness.', 'A liabilities/equity cutoff does not distinguish every type of obligation.', 'A failed screen does not establish fraud or mispricing.']
        data['what_changes_my_mind'] = ['A filing-based explanation of cash conversion and the obligations behind the balance sheet.', 'Sustained cash backing and a balance sheet that meets the retained rule.']
        data['private_assessment'] = 'I would investigate the gaps before acting. The shared figures cannot tell me whether the market is wrong, and I will not invent an accounting allegation.'
    data['holdings_context'] = {k: 'not known: actual investor positions and trades were not collected.' for k in data['holdings_context']}
    data['would_buy_at'] = data['would_sell_at'] = 'not known: no price assessment.'
    flags = audit(claim_values(data), report)
    if flags:
        raise ValueError(flags)
    return data

def label(key):
    return key.replace('_', ' ').replace('5yr', 'Five year').replace('2029', 'future').capitalize()

def memo_markdown(investor, verdict, data):
    lines = [f'# {investor}: {verdict}', 'AI simulation; not an authentic investor statement. Signal describes business-screen fit, not an expected stock return.',
             '## Thesis', data['thesis'], '## Forward outlook',
             'Not known. No forecast, timeline, catalyst or price target is established by this screen.', '## Analysis']
    for key, section in data['analysis'].items():
        lines += ['### '+label(key)]
        if key == 'innovation_trajectory':
            lines += ['R&D intensity: '+section['rd_intensity']+'.']
        lines += [section.get('reasoning', section.get('methodology', 'Not known: the required evidence or model is not included.'))]
    for key in ('key_risks', 'what_changes_my_mind'):
        lines += ['## '+label(key), '\n'.join('- '+v for v in data[key])]
    lines += ['## Holdings context', 'Not known: actual investor holdings and recent trades were not collected.',
              '## Price levels', 'Buy and sell levels: not known. No valuation is included.',
              '## Private assessment', data['private_assessment'],
              'Confidence and qualitative scores: not known; no unsupported scores are assigned.']
    return '\n\n'.join(lines)+'\n'

def provenance(slug):
    return {'source_url': source_url(slug), 'sha256': hashlib.sha256(source_path(slug).read_bytes()).hexdigest(),
            'retrieved_on': '2026-11-05', 'format_policy': 'Original field names and nesting retained. Unsupported numeric, boolean and categorical values use not known; this is a classroom adaptation, not strict upstream type compliance.'}
