"""Shared evidence and independent classroom checks; no forecasts or prices."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'buffett_skill' / 'scripts'))
from edgar import build_report, numeric, printed, table, NUMBER, number_key

OUTPUT = Path(__file__).parent / 'output'
INVESTORS = ('Buffett', 'Cathie Wood', 'Burry')
SLUGS = ('buffett', 'cathie-wood', 'burry')
DEFAULT_GROWTH = .15

def evaluate(report, growth_threshold=DEFAULT_GROWTH):
    rows = report['rows']
    first, last = rows[0], rows[-1]
    a, b = first['revenue']['value'], last['revenue']['value']
    growth = (b / a) ** (1 / 4) - 1 if len(rows) == 5 and numeric(a) and numeric(b) and a > 0 and b >= 0 else 'not known'
    rd = last['rd_to_revenue']['value']
    leverage = last['liabilities_to_equity']['value']
    def check(value, predicate):
        return ('pass' if predicate(value) else 'fail') if numeric(value) else 'not known'
    cash = [(r['operating_cash_flow']['value'], r['net_income']['value']) for r in rows]
    cash_result = 'not known' if len(cash) != 5 or not all(numeric(a) and numeric(b) for a,b in cash) else ('pass' if all(a >= b for a,b in cash) else 'fail')
    checks = [{'Investor': 'Buffett', 'Check': name, 'Result': result} for name,result in report['checks'].items()]
    checks += [
        {'Investor': 'Cathie Wood', 'Check': f'Revenue growth at least {growth_threshold:.0%} a year, first to last', 'Result': check(growth, lambda v: v >= growth_threshold)},
        {'Investor': 'Cathie Wood', 'Check': 'R&D at least 5% of revenue, latest year', 'Result': check(rd, lambda v: v >= .05)},
        {'Investor': 'Burry', 'Check': 'Operating cash flow at least net income every year', 'Result': cash_result},
        {'Investor': 'Burry', 'Check': 'Liabilities no more than twice equity, latest year', 'Result': check(leverage, lambda v: v <= 2)},
    ]
    return {'checks': checks, 'growth': growth, 'growth_threshold': growth_threshold,
            'growth_display': f'{growth:.2%}' if numeric(growth) else growth,
            'leverage_display': f'{leverage:.2f}' if numeric(leverage) else leverage}

def panel_printed(report, threshold=DEFAULT_GROWTH):
    panel = evaluate(report, threshold)
    lines = [printed(report), '## Panel evidence',
             f"Revenue growth a year: {panel['growth_display']}",
             f"Growth threshold: {threshold:.0%}; R&D threshold: 5%; liabilities/equity ceiling: 2",
             f"Latest liabilities/equity, rounded: {panel['leverage_display']}",
             '| Investor | Check | Result |', '| --- | --- | --- |']
    lines += [f"| {r['Investor']} | {r['Check']} | {r['Result']} |" for r in panel['checks']]
    return '\n'.join(lines) + '\n'

def audit(memo, report, threshold=DEFAULT_GROWTH):
    p = evaluate(report, threshold)
    cells = [v for r in table(report) for v in r.values()] + [p['growth_display'], p['leverage_display'], f'{threshold:.0%}', '15%', '5%', '2']
    allowed = {number_key(m.group()) for c in cells for m in NUMBER.finditer(c)}
    return [{'number': m.group().strip(), 'line': memo[:m.start()].count('\n')+1}
            for m in NUMBER.finditer(memo) if number_key(m.group()) not in allowed]

def binding(report, threshold=DEFAULT_GROWTH):
    return hashlib.sha256((report['facts_sha256'] + panel_printed(report, threshold)).encode()).hexdigest()

def rebuild(ticker):
    path = OUTPUT / f'{ticker}-report.json'
    previous = json.loads(path.read_text(encoding='utf-8'))
    facts = json.loads((OUTPUT / f'{ticker}-facts.json').read_text(encoding='utf-8'))
    report = build_report(facts, ticker)
    report['retrieved_at'] = previous['retrieved_at']
    report['source_url'] = previous.get('source_url', f"https://data.sec.gov/api/xbrl/companyfacts/CIK{int(report['cik']):010d}.json")
    path.write_text(json.dumps(report, indent=2), encoding='utf-8')
    (OUTPUT / f'{ticker}-numbers.md').write_text(printed(report), encoding='utf-8')
    (OUTPUT / f'{ticker}-panel-numbers.md').write_text(panel_printed(report), encoding='utf-8')
    return report

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('ticker')
    args = parser.parse_args()
    print(panel_printed(rebuild(args.ticker.upper())))
