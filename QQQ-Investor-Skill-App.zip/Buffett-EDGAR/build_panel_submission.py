"""Package reviewed AI-authored memos with code-computed evidence."""
import html
import json
from pathlib import Path
from panel import OUTPUT, INVESTORS, SLUGS, evaluate, audit, binding, table
from expert_format import structure, memo_markdown, provenance

MEMOS = {
    'COST': [
        ('own the business', 'I would own the business on this business-quality screen. ROE clears the hurdle every year, owner earnings are positive throughout, and owner earnings rise from $3,501 million to $9,382 million. The cash evidence supports a profitable business with room to reinvest. It does not establish a durable moat, management quality, or an attractive purchase price; those require further work.'),
        ('pass', 'I would pass under this growth-and-innovation screen. Revenue growth of 7.51% falls below the 15% hurdle. ResearchAndDevelopmentExpense is not found, so the R&D check is not known; missing disclosure is not evidence of no innovation. The results do not establish disruptive technology or future market expansion. A sound cash-generating business can still fall outside this particular screen.'),
        ('watch it', 'I would watch it. Operating cash flow covers net income in every selected year, and latest liabilities/equity is 1.49, below the ceiling of 2. These checks support cash backing and a manageable balance sheet under the classroom rule. I still need to examine footnotes, obligations and the sustainability of cash generation. Passing these ratios does not prove the absence of accounting risk or establish an attractive price.'),
    ],
    'AAPL': [
        ('own the business', 'I would own the business on this business-quality screen. ROE exceeds 15% every year, owner earnings remain positive, and owner earnings grow from 111,443 million USD to 136,056 million USD. Growth is first-to-last, not uninterrupted: owner earnings fall in some intervening years. Strong cash generation supports the business case, but unusually high ROE needs interpretation alongside the equity base. These checks do not prove a durable moat, sound management or an attractive stock price.'),
        ('pass', 'I would pass under this high-growth screen. Revenue growth of 4.97% is below the 15% hurdle. Latest R&D intensity of 9.56% passes the 5% test, so the result is mixed: research investment is visible, but historical revenue growth does not meet the chosen standard. R&D spending alone cannot prove successful innovation or future growth. I would require more evidence before treating the company as a disruptive-growth investment.'),
        ('pass', 'I would pass under these classroom rules. On 2025-09-27, operating cash flow of 111,482 million USD is below net income of 112,010 million USD, so the every-year cash-backing check fails despite stronger latest cash flow. Latest liabilities/equity is 2.61, above the ceiling of 2. I would investigate working-capital timing and the composition of liabilities and equity. These failed checks are research flags, not proof of manipulation or insolvency.'),
    ],
}

METHOD = """The panel uses a single saved SEC Company Facts snapshot for each company. COST uses the saved classroom snapshot; AAPL was downloaded from SEC on November 5, 2026 and saved for reproducibility. Only annual 10-K facts qualify; fiscal dates come from annual periods, and the latest filing wins within each preferred tag. The original revenue, cash flow, capital spending, equity, ROE and owner-earnings rules are preserved. Liabilities and ResearchAndDevelopmentExpense are the added source tags. No missing values are replaced with estimates or zero.

ROE = net income / year-end equity. Owner earnings = operating cash flow - capital spending, a classroom proxy rather than maintenance-capital-expenditure analysis. Revenue growth a year = (last revenue / first revenue)^(1/4) - 1. R&D intensity = ResearchAndDevelopmentExpense / revenue. Liabilities/equity = Liabilities / StockholdersEquity. A ratio with missing inputs or a nonpositive denominator is not known; a missing raw fact is not found. Comparisons use unrounded values.

The skills adapt FAskills' business-quality, innovation and accounting-quality lenses to the assignment's narrow checks. They are AI simulations, not authentic statements or a complete implementation of those investors' methods. Code computes the evidence; separately authored memos interpret it. Their agreement is not independent confirmation because all read the same data and share its omissions. The number audit checks printed numeric tokens and units, not whether a claim uses the right metric; the metric associations were also reviewed."""

DISCUSSION = """Company selection: My fund is Invesco QQQ. Invesco's holdings list dated November 3, 2026 ranks Apple (AAPL) first at 8.13%, ahead of NVIDIA at 8.02%. Apple files annual reports on EDGAR, so no fallback company is needed. This selection uses the dated issuer list rather than conflicting third-party summaries.

Agreement and split: On COST, Buffett is favorable, Burry's checks pass but his memo calls for further investigation, and Cathie Wood rejects the growth fit. On AAPL, Buffett passes every check and gives a favorable business-quality verdict. Cathie Wood passes on the investment because growth fails even though R&D passes. Burry passes because both cash backing and liabilities/equity fail. They agree on the facts, but emphasize different evidence. Positive owner earnings and cash flow below net income in one year can both be true. All agree that the screen cannot establish a fair stock price.

Bull case for AAPL: ROE clears the hurdle every year, owner earnings remain positive and finish above their starting value, and latest R&D intensity passes. This supports a profitable business that generates cash while investing in research. A durable competitive advantage and productive future research remain hypotheses requiring further evidence.

Bear case for AAPL: Historical growth misses the chosen hurdle, operating cash flow falls below net income in a selected year, and latest liabilities exceed twice equity. Cash conversion and capital structure need review. High ROE can reflect a small equity base as well as operating strength; the panel alone does not establish the cause. R&D spending does not guarantee successful products. All required source inputs are found for AAPL; COST's missing R&D stays explicit.

Threshold probe: COST's growth result changes from fail at 15% to pass at 5%, while R&D stays not known. AAPL's 4.97% growth fails at both thresholds; its R&D check passes in both cases. The same facts can produce different labels when the analyst changes the cutoff. A changed growth check does not automatically change an authored investment verdict.

My decision: I would trust the panel for initial screening, but only if missing data stay explicit and I review industry differences and valuation before investing."""

def md_table(rows):
    columns = list(rows[0])
    return '\n'.join(['| ' + ' | '.join(columns) + ' |', '| ' + ' | '.join(['---']*len(columns)) + ' |'] + ['| ' + ' | '.join(str(row[c]) for c in columns) + ' |' for row in rows])

def html_table(rows):
    columns = list(rows[0])
    return '<div class="scroll"><table><thead><tr>' + ''.join('<th>'+html.escape(c)+'</th>' for c in columns) + '</tr></thead><tbody>' + ''.join('<tr>'+''.join('<td>'+html.escape(str(row[c]))+'</td>' for c in columns)+'</tr>' for row in rows) + '</tbody></table></div>'

def paragraphs(text):
    blocks = []
    for p in text.split('\n\n'):
        if p.startswith('### '):
            blocks.append('<h4>'+html.escape(p[4:])+'</h4>')
        elif p.startswith('## '):
            blocks.append('<h4>'+html.escape(p[3:])+'</h4>')
        elif p.startswith('- '):
            blocks.append('<ul>'+''.join('<li>'+html.escape(x[2:])+'</li>' for x in p.splitlines())+'</ul>')
        else:
            blocks.append('<p>'+html.escape(p)+'</p>')
    return ''.join(blocks)

def main():
    md = ['# Investor panel — individual submission', 'Jack Ryan', '## Method', METHOD]
    body = '<h1>Investor panel</h1><p>Jack Ryan · Individual submission</p><h2>Method</h2>'+paragraphs(METHOD)
    for ticker in MEMOS:
        report = json.loads((OUTPUT/f'{ticker}-report.json').read_text(encoding='utf-8'))
        panel = evaluate(report)
        evidence = [{ 'FY end': r['Fiscal year end'], 'R&D expense (USD millions)': r['research_and_development'],
                      'R&D / revenue': r['rd_to_revenue'],
                      'Liabilities / equity': r['liabilities_to_equity']} for r in table(report)]
        title = ticker + ' — ' + report['company']
        summary = f"Revenue growth a year: {panel['growth_display']}. Saved snapshot retrieved {report['retrieved_at']}."
        md += ['## '+title, summary, md_table(evidence), md_table(panel['checks'])]
        body += '<h2>'+html.escape(title)+'</h2><p>'+html.escape(summary)+'</p>'+html_table(evidence)+html_table(panel['checks'])+'<div class="memos">'
        for investor, slug, (verdict, text) in zip(INVESTORS, SLUGS, MEMOS[ticker]):
            structured = structure(report, slug, verdict, text)
            memo = memo_markdown(investor, verdict, structured)
            (OUTPUT/f'{ticker}-{slug}-analysis.json').write_text(json.dumps(structured, indent=2), encoding='utf-8')
            source_metadata = {**provenance(slug), 'report_binding': binding(report)}
            (OUTPUT/f'{ticker}-{slug}-format-source.json').write_text(json.dumps(source_metadata, indent=2), encoding='utf-8')
            if slug == 'cathie-wood':
                memo += '\nThreshold kept: 15%, because this lens is intended to identify high growth rather than fit the example.\n'
            assert not audit(memo, report), (ticker, investor, audit(memo, report))
            (OUTPUT/f'{ticker}-{slug}-memo.md').write_text(memo, encoding='utf-8')
            (OUTPUT/f'{ticker}-{slug}-memo-source.txt').write_text(binding(report), encoding='utf-8')
            if ticker == 'AAPL' and slug == 'buffett':
                (OUTPUT/f'{ticker}-memo.md').write_text(memo, encoding='utf-8')
                (OUTPUT/f'{ticker}-memo-source.txt').write_text(report['facts_sha256'], encoding='utf-8')
            md += [memo]
            body += '<article><h3>'+html.escape(investor)+'</h3><strong>'+html.escape(verdict)+'</strong>'+paragraphs('\n\n'.join(memo.split('\n\n')[1:]))+'</article>'
        body += '</div>'
        md += ['Number audit: all investor memos passed. See the verification file for injected-number tests.', '[Full printed evidence](output/'+ticker+'-panel-numbers.md)', '[SEC Company Facts]('+report['source_url']+')']
        body += '<p>Number audit: all investor memos passed. <a href="output/'+ticker+'-panel-numbers.md">Full printed evidence and filing provenance</a> · <a href="'+report['source_url']+'">SEC Company Facts</a></p>'
    md += ['## Interpretation and decision', DISCUSSION, '## Sources',
           '- [QQQ holdings — Invesco](https://www.invesco.com/qqq-etf/en/about.html)',
           '- [Cathie Wood — FAskills](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/cathie_wood.md)',
           '- [Burry — FAskills](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/michael_burry.md)',
           '- [Buffett — FAskills](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/warren_buffett.md)',
           '- [SEC API documentation](https://www.sec.gov/search-filings/edgar-application-programming-interfaces)',
           '- [Streamlit documentation](https://docs.streamlit.io/)']
    body += '<h2>Interpretation and decision</h2>'+paragraphs(DISCUSSION)+'<h2>Sources</h2><p>Investor philosophy: <a href="https://github.com/CinderZhang/FAskills/tree/main/financial-researcher/experts">FAskills investor pages</a>. Data: <a href="https://www.sec.gov/search-filings/edgar-application-programming-interfaces">SEC EDGAR</a>. App: <a href="https://docs.streamlit.io/">Streamlit</a>.</p>'
    dest = Path(__file__).parent
    (OUTPUT/'AAPL-decision.md').write_text(DISCUSSION.split('My decision: ')[1], encoding='utf-8')
    (dest/'Investor-Panel-Submission.md').write_text('\n\n'.join(md), encoding='utf-8')
    style = 'body{font:16px/1.6 system-ui,sans-serif;max-width:1300px;margin:40px auto;padding:0 24px;color:#172638;background:#fafbfc}h1,h2,h3{line-height:1.25}h2{margin-top:36px}table{border-collapse:collapse;width:100%;margin:20px 0;font-size:14px}td,th{border:1px solid #cbd5e1;padding:10px;text-align:left}th{background:#e8eef5}.memos{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}article{background:white;border:1px solid #cbd5e1;padding:20px;border-radius:8px}.scroll{overflow:auto}a{color:#165ac4}@media(max-width:850px){.memos{grid-template-columns:1fr}}@media print{body{font-size:11px;margin:0}article{break-inside:avoid}h2{break-after:avoid}}'
    (dest/'Investor-Panel-Report.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Investor panel — Jack Ryan</title><style>'+style+'</style><body>'+body+'</body></html>', encoding='utf-8')
    (dest/'Investor-Panel-Submission.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>QQQ investor skill app</title><body style="font:18px system-ui;max-width:720px;margin:80px auto"><h1>QQQ investor skill app</h1><p>The submission is now an interactive Streamlit app with AAPL and COST panels, editable investor memos, number audits, and the threshold probe.</p><p><a href="http://localhost:8504">Open the skill app</a></p><p>If the app is not running, double-click <b>Run Investor Panel.cmd</b> in this folder.</p><p><a href="Investor-Panel-Report.html">Open the static report backup</a></p></body></html>', encoding='utf-8')
    print('Wrote submission and six audited, source-bound memos.')

if __name__ == '__main__':
    main()
