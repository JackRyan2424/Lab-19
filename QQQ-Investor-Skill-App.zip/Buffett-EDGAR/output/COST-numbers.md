# COST — COSTCO WHOLESALE CORP /NEW
Dollar amounts in USD millions; ROE in percent; liabilities/equity is a ratio.
| Fiscal year end | revenue | net_income | operating_cash_flow | capital_spending | equity | liabilities | research_and_development | roe | owner_earnings | liabilities_to_equity | rd_to_revenue |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2022-08-28 | 226,954 | 5,844 | 7,392 | 3,891 | 20,642 | 43,519 | not found | 28.3% | 3,501 | 2.108 | not known |
| 2023-09-03 | 242,290 | 6,292 | 11,068 | 4,323 | 25,058 | 43,936 | not found | 25.1% | 6,745 | 1.753 | not known |
| 2024-09-01 | 254,453 | 7,367 | 11,339 | 4,710 | 23,622 | 46,209 | not found | 31.2% | 6,629 | 1.956 | not known |
| 2025-08-31 | 275,235 | 8,099 | 13,335 | 5,498 | 29,164 | 47,935 | not found | 27.8% | 7,837 | 1.644 | not known |
| 2026-08-30 | 303,154 | 9,226 | 15,817 | 6,435 | 35,803 | 53,242 | not found | 25.8% | 9,382 | 1.487 | not known |
- ROE of 15% or more every year: pass
- Owner earnings positive every year: pass
- Owner earnings grew, first year to last: pass

Tags and provenance (derived metrics have no standalone XBRL tag):
- 2022-08-28 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2024-10-09; accession 0000909832-24-000049
- 2022-08-28 net_income: us-gaap:NetIncomeLoss; filed 2024-10-09; accession 0000909832-24-000049
- 2022-08-28 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2024-10-09; accession 0000909832-24-000049
- 2022-08-28 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2024-10-09; accession 0000909832-24-000049
- 2022-08-28 equity: us-gaap:StockholdersEquity; filed 2023-10-11; accession 0000909832-23-000042
- 2022-08-28 liabilities: us-gaap:Liabilities; filed 2023-10-11; accession 0000909832-23-000042
- 2022-08-28 research_and_development: not found; filed derived or not found; accession derived or not found
- 2022-08-28 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2022-08-28 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2022-08-28 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2022-08-28 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2023-09-03 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2025-10-08; accession 0000909832-25-000101
- 2023-09-03 net_income: us-gaap:NetIncomeLoss; filed 2025-10-08; accession 0000909832-25-000101
- 2023-09-03 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2025-10-08; accession 0000909832-25-000101
- 2023-09-03 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2025-10-08; accession 0000909832-25-000101
- 2023-09-03 equity: us-gaap:StockholdersEquity; filed 2026-10-07; accession 0000909832-26-000093
- 2023-09-03 liabilities: us-gaap:Liabilities; filed 2024-10-09; accession 0000909832-24-000049
- 2023-09-03 research_and_development: not found; filed derived or not found; accession derived or not found
- 2023-09-03 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2023-09-03 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2023-09-03 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2023-09-03 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2024-09-01 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2026-10-07; accession 0000909832-26-000093
- 2024-09-01 net_income: us-gaap:NetIncomeLoss; filed 2026-10-07; accession 0000909832-26-000093
- 2024-09-01 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-10-07; accession 0000909832-26-000093
- 2024-09-01 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2026-10-07; accession 0000909832-26-000093
- 2024-09-01 equity: us-gaap:StockholdersEquity; filed 2026-10-07; accession 0000909832-26-000093
- 2024-09-01 liabilities: us-gaap:Liabilities; filed 2025-10-08; accession 0000909832-25-000101
- 2024-09-01 research_and_development: not found; filed derived or not found; accession derived or not found
- 2024-09-01 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2024-09-01 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2024-09-01 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2024-09-01 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2025-08-31 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2026-10-07; accession 0000909832-26-000093
- 2025-08-31 net_income: us-gaap:NetIncomeLoss; filed 2026-10-07; accession 0000909832-26-000093
- 2025-08-31 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-10-07; accession 0000909832-26-000093
- 2025-08-31 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2026-10-07; accession 0000909832-26-000093
- 2025-08-31 equity: us-gaap:StockholdersEquity; filed 2026-10-07; accession 0000909832-26-000093
- 2025-08-31 liabilities: us-gaap:Liabilities; filed 2026-10-07; accession 0000909832-26-000093
- 2025-08-31 research_and_development: not found; filed derived or not found; accession derived or not found
- 2025-08-31 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2025-08-31 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2025-08-31 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2025-08-31 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2026-08-30 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2026-10-07; accession 0000909832-26-000093
- 2026-08-30 net_income: us-gaap:NetIncomeLoss; filed 2026-10-07; accession 0000909832-26-000093
- 2026-08-30 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-10-07; accession 0000909832-26-000093
- 2026-08-30 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2026-10-07; accession 0000909832-26-000093
- 2026-08-30 equity: us-gaap:StockholdersEquity; filed 2026-10-07; accession 0000909832-26-000093
- 2026-08-30 liabilities: us-gaap:Liabilities; filed 2026-10-07; accession 0000909832-26-000093
- 2026-08-30 research_and_development: not found; filed derived or not found; accession derived or not found
- 2026-08-30 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2026-08-30 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2026-08-30 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2026-08-30 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
