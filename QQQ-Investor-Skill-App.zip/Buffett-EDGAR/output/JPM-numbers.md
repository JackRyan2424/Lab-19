# JPM — JPMORGAN CHASE & CO
Dollar amounts in USD millions; ROE in percent; liabilities/equity is a ratio.
| Fiscal year end | revenue | net_income | operating_cash_flow | capital_spending | equity | liabilities | research_and_development | roe | owner_earnings | liabilities_to_equity | rd_to_revenue |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2021-12-31 | 121,649 | 48,334 | 78,084 | not found | 294,127 | 3,449,440 | not found | 16.4% | not found | 11.728 | not known |
| 2022-12-31 | 128,695 | 37,676 | 107,119 | not found | 292,332 | 3,373,411 | not found | 12.9% | not found | 11.540 | not known |
| 2023-12-31 | 158,104 | 49,552 | 12,974 | not found | 327,878 | 3,547,515 | not found | 15.1% | not found | 10.820 | not known |
| 2024-12-31 | 177,556 | 58,471 | -42,012 | not found | 344,758 | 3,658,056 | not found | 17.0% | not found | 10.611 | not known |
| 2025-12-31 | 182,447 | 57,048 | -147,782 | not found | 362,438 | 4,062,462 | not found | 15.7% | not found | 11.209 | not known |
- ROE of 15% or more every year: fail
- Owner earnings positive every year: not known
- Owner earnings grew, first year to last: not known

Tags and provenance (derived metrics have no standalone XBRL tag):
- 2021-12-31 revenue: us-gaap:Revenues; filed 2024-02-16; accession 0000019617-24-000225
- 2021-12-31 net_income: us-gaap:NetIncomeLoss; filed 2024-02-16; accession 0000019617-24-000225
- 2021-12-31 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2024-02-16; accession 0000019617-24-000225
- 2021-12-31 capital_spending: not found; filed derived or not found; accession derived or not found
- 2021-12-31 equity: us-gaap:StockholdersEquity; filed 2024-02-16; accession 0000019617-24-000225
- 2021-12-31 liabilities: us-gaap:Liabilities; filed 2023-02-21; accession 0000019617-23-000231
- 2021-12-31 research_and_development: not found; filed derived or not found; accession derived or not found
- 2021-12-31 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2021-12-31 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; filed derived or not found; accession derived or not found
- 2021-12-31 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2021-12-31 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2022-12-31 revenue: us-gaap:Revenues; filed 2025-02-14; accession 0000019617-25-000270
- 2022-12-31 net_income: us-gaap:NetIncomeLoss; filed 2025-02-14; accession 0000019617-25-000270
- 2022-12-31 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2025-02-14; accession 0000019617-25-000270
- 2022-12-31 capital_spending: not found; filed derived or not found; accession derived or not found
- 2022-12-31 equity: us-gaap:StockholdersEquity; filed 2025-02-14; accession 0000019617-25-000270
- 2022-12-31 liabilities: us-gaap:Liabilities; filed 2024-02-16; accession 0000019617-24-000225
- 2022-12-31 research_and_development: not found; filed derived or not found; accession derived or not found
- 2022-12-31 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2022-12-31 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; filed derived or not found; accession derived or not found
- 2022-12-31 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2022-12-31 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2023-12-31 revenue: us-gaap:Revenues; filed 2026-02-13; accession 0001628280-26-008131
- 2023-12-31 net_income: us-gaap:NetIncomeLoss; filed 2026-02-13; accession 0001628280-26-008131
- 2023-12-31 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-02-13; accession 0001628280-26-008131
- 2023-12-31 capital_spending: not found; filed derived or not found; accession derived or not found
- 2023-12-31 equity: us-gaap:StockholdersEquity; filed 2026-02-13; accession 0001628280-26-008131
- 2023-12-31 liabilities: us-gaap:Liabilities; filed 2025-02-14; accession 0000019617-25-000270
- 2023-12-31 research_and_development: not found; filed derived or not found; accession derived or not found
- 2023-12-31 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2023-12-31 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; filed derived or not found; accession derived or not found
- 2023-12-31 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2023-12-31 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2024-12-31 revenue: us-gaap:Revenues; filed 2026-02-13; accession 0001628280-26-008131
- 2024-12-31 net_income: us-gaap:NetIncomeLoss; filed 2026-02-13; accession 0001628280-26-008131
- 2024-12-31 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-02-13; accession 0001628280-26-008131
- 2024-12-31 capital_spending: not found; filed derived or not found; accession derived or not found
- 2024-12-31 equity: us-gaap:StockholdersEquity; filed 2026-02-13; accession 0001628280-26-008131
- 2024-12-31 liabilities: us-gaap:Liabilities; filed 2026-02-13; accession 0001628280-26-008131
- 2024-12-31 research_and_development: not found; filed derived or not found; accession derived or not found
- 2024-12-31 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2024-12-31 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; filed derived or not found; accession derived or not found
- 2024-12-31 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2024-12-31 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2025-12-31 revenue: us-gaap:Revenues; filed 2026-02-13; accession 0001628280-26-008131
- 2025-12-31 net_income: us-gaap:NetIncomeLoss; filed 2026-02-13; accession 0001628280-26-008131
- 2025-12-31 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-02-13; accession 0001628280-26-008131
- 2025-12-31 capital_spending: not found; filed derived or not found; accession derived or not found
- 2025-12-31 equity: us-gaap:StockholdersEquity; filed 2026-02-13; accession 0001628280-26-008131
- 2025-12-31 liabilities: us-gaap:Liabilities; filed 2026-02-13; accession 0001628280-26-008131
- 2025-12-31 research_and_development: not found; filed derived or not found; accession derived or not found
- 2025-12-31 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2025-12-31 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - not found; filed derived or not found; accession derived or not found
- 2025-12-31 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2025-12-31 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
