# AAPL — Apple Inc.
Dollar amounts in USD millions; ROE in percent; liabilities/equity is a ratio.
| Fiscal year end | revenue | net_income | operating_cash_flow | capital_spending | equity | liabilities | research_and_development | roe | owner_earnings | liabilities_to_equity | rd_to_revenue |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2022-09-24 | 394,328 | 99,803 | 122,151 | 10,708 | 50,672 | 302,083 | 26,251 | 197.0% | 111,443 | 5.962 | 6.66% |
| 2023-09-30 | 383,285 | 96,995 | 110,543 | 10,959 | 62,146 | 290,437 | 29,915 | 156.1% | 99,584 | 4.673 | 7.80% |
| 2024-09-28 | 391,035 | 93,736 | 118,254 | 9,447 | 56,950 | 308,030 | 31,370 | 164.6% | 108,807 | 5.409 | 8.02% |
| 2025-09-27 | 416,161 | 112,010 | 111,482 | 12,715 | 73,733 | 285,508 | 34,550 | 151.9% | 98,767 | 3.872 | 8.30% |
| 2026-09-26 | 478,834 | 132,175 | 145,097 | 9,041 | 112,093 | 292,455 | 45,765 | 117.9% | 136,056 | 2.609 | 9.56% |
- ROE of 15% or more every year: pass
- Owner earnings positive every year: pass
- Owner earnings grew, first year to last: pass

Tags and provenance (derived metrics have no standalone XBRL tag):
- 2022-09-24 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2024-11-01; accession 0000320193-24-000123
- 2022-09-24 net_income: us-gaap:NetIncomeLoss; filed 2024-11-01; accession 0000320193-24-000123
- 2022-09-24 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2024-11-01; accession 0000320193-24-000123
- 2022-09-24 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2024-11-01; accession 0000320193-24-000123
- 2022-09-24 equity: us-gaap:StockholdersEquity; filed 2025-10-31; accession 0000320193-25-000079
- 2022-09-24 liabilities: us-gaap:Liabilities; filed 2023-11-03; accession 0000320193-23-000106
- 2022-09-24 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2024-11-01; accession 0000320193-24-000123
- 2022-09-24 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2022-09-24 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2022-09-24 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2022-09-24 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2023-09-30 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2025-10-31; accession 0000320193-25-000079
- 2023-09-30 net_income: us-gaap:NetIncomeLoss; filed 2025-10-31; accession 0000320193-25-000079
- 2023-09-30 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2025-10-31; accession 0000320193-25-000079
- 2023-09-30 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2025-10-31; accession 0000320193-25-000079
- 2023-09-30 equity: us-gaap:StockholdersEquity; filed 2026-11-03; accession 0000320193-26-000026
- 2023-09-30 liabilities: us-gaap:Liabilities; filed 2024-11-01; accession 0000320193-24-000123
- 2023-09-30 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2025-10-31; accession 0000320193-25-000079
- 2023-09-30 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2023-09-30 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2023-09-30 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2023-09-30 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2024-09-28 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2026-11-03; accession 0000320193-26-000026
- 2024-09-28 net_income: us-gaap:NetIncomeLoss; filed 2026-11-03; accession 0000320193-26-000026
- 2024-09-28 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-11-03; accession 0000320193-26-000026
- 2024-09-28 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2026-11-03; accession 0000320193-26-000026
- 2024-09-28 equity: us-gaap:StockholdersEquity; filed 2026-11-03; accession 0000320193-26-000026
- 2024-09-28 liabilities: us-gaap:Liabilities; filed 2025-10-31; accession 0000320193-25-000079
- 2024-09-28 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2026-11-03; accession 0000320193-26-000026
- 2024-09-28 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2024-09-28 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2024-09-28 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2024-09-28 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2025-09-27 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2026-11-03; accession 0000320193-26-000026
- 2025-09-27 net_income: us-gaap:NetIncomeLoss; filed 2026-11-03; accession 0000320193-26-000026
- 2025-09-27 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-11-03; accession 0000320193-26-000026
- 2025-09-27 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2026-11-03; accession 0000320193-26-000026
- 2025-09-27 equity: us-gaap:StockholdersEquity; filed 2026-11-03; accession 0000320193-26-000026
- 2025-09-27 liabilities: us-gaap:Liabilities; filed 2026-11-03; accession 0000320193-26-000026
- 2025-09-27 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2026-11-03; accession 0000320193-26-000026
- 2025-09-27 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2025-09-27 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2025-09-27 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2025-09-27 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2026-09-26 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2026-11-03; accession 0000320193-26-000026
- 2026-09-26 net_income: us-gaap:NetIncomeLoss; filed 2026-11-03; accession 0000320193-26-000026
- 2026-09-26 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-11-03; accession 0000320193-26-000026
- 2026-09-26 capital_spending: us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed 2026-11-03; accession 0000320193-26-000026
- 2026-09-26 equity: us-gaap:StockholdersEquity; filed 2026-11-03; accession 0000320193-26-000026
- 2026-09-26 liabilities: us-gaap:Liabilities; filed 2026-11-03; accession 0000320193-26-000026
- 2026-09-26 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2026-11-03; accession 0000320193-26-000026
- 2026-09-26 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2026-09-26 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquirePropertyPlantAndEquipment; filed derived or not found; accession derived or not found
- 2026-09-26 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2026-09-26 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found

## Panel evidence
Revenue growth a year: 4.97%
Growth threshold: 15%; R&D threshold: 5%; liabilities/equity ceiling: 2
Latest liabilities/equity, rounded: 2.61
| Investor | Check | Result |
| --- | --- | --- |
| Buffett | ROE of 15% or more every year | pass |
| Buffett | Owner earnings positive every year | pass |
| Buffett | Owner earnings grew, first year to last | pass |
| Cathie Wood | Revenue growth at least 15% a year, first to last | fail |
| Cathie Wood | R&D at least 5% of revenue, latest year | pass |
| Burry | Operating cash flow at least net income every year | fail |
| Burry | Liabilities no more than twice equity, latest year | fail |
