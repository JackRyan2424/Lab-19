# NVDA — NVIDIA CORP
Dollar amounts in USD millions; ROE in percent; liabilities/equity is a ratio.
| Fiscal year end | revenue | net_income | operating_cash_flow | capital_spending | equity | liabilities | research_and_development | roe | owner_earnings | liabilities_to_equity | rd_to_revenue |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 2022-01-30 | 26,914 | 9,752 | 9,108 | 976 | 26,612 | 17,575 | 5,268 | 36.6% | 8,132 | 0.660 | 19.57% |
| 2023-01-29 | 26,974 | 4,368 | 5,641 | 1,833 | 22,101 | 19,081 | 7,339 | 19.8% | 3,808 | 0.863 | 27.21% |
| 2024-01-28 | 60,922 | 29,760 | 28,090 | 1,069 | 42,978 | 22,750 | 8,675 | 69.2% | 27,021 | 0.529 | 14.24% |
| 2025-01-26 | 130,497 | 72,880 | 64,089 | 3,236 | 79,327 | 32,274 | 12,914 | 91.9% | 60,853 | 0.407 | 9.90% |
| 2026-01-25 | 215,938 | 120,067 | 102,718 | 6,042 | 157,293 | 49,510 | 18,497 | 76.3% | 96,676 | 0.315 | 8.57% |
- ROE of 15% or more every year: pass
- Owner earnings positive every year: pass
- Owner earnings grew, first year to last: pass

Tags and provenance (derived metrics have no standalone XBRL tag):
- 2022-01-30 revenue: us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax; filed 2022-03-18; accession 0001045810-22-000036
- 2022-01-30 net_income: us-gaap:NetIncomeLoss; filed 2024-02-21; accession 0001045810-24-000029
- 2022-01-30 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2024-02-21; accession 0001045810-24-000029
- 2022-01-30 capital_spending: us-gaap:PaymentsToAcquireProductiveAssets; filed 2024-02-21; accession 0001045810-24-000029
- 2022-01-30 equity: us-gaap:StockholdersEquity; filed 2025-02-26; accession 0001045810-25-000023
- 2022-01-30 liabilities: us-gaap:Liabilities; filed 2023-02-24; accession 0001045810-23-000017
- 2022-01-30 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2024-02-21; accession 0001045810-24-000029
- 2022-01-30 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2022-01-30 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets; filed derived or not found; accession derived or not found
- 2022-01-30 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2022-01-30 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2023-01-29 revenue: us-gaap:Revenues; filed 2025-02-26; accession 0001045810-25-000023
- 2023-01-29 net_income: us-gaap:NetIncomeLoss; filed 2025-02-26; accession 0001045810-25-000023
- 2023-01-29 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2025-02-26; accession 0001045810-25-000023
- 2023-01-29 capital_spending: us-gaap:PaymentsToAcquireProductiveAssets; filed 2025-02-26; accession 0001045810-25-000023
- 2023-01-29 equity: us-gaap:StockholdersEquity; filed 2026-02-25; accession 0001045810-26-000021
- 2023-01-29 liabilities: us-gaap:Liabilities; filed 2024-02-21; accession 0001045810-24-000029
- 2023-01-29 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2025-02-26; accession 0001045810-25-000023
- 2023-01-29 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2023-01-29 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets; filed derived or not found; accession derived or not found
- 2023-01-29 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2023-01-29 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2024-01-28 revenue: us-gaap:Revenues; filed 2026-02-25; accession 0001045810-26-000021
- 2024-01-28 net_income: us-gaap:NetIncomeLoss; filed 2026-02-25; accession 0001045810-26-000021
- 2024-01-28 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-02-25; accession 0001045810-26-000021
- 2024-01-28 capital_spending: us-gaap:PaymentsToAcquireProductiveAssets; filed 2026-02-25; accession 0001045810-26-000021
- 2024-01-28 equity: us-gaap:StockholdersEquity; filed 2026-02-25; accession 0001045810-26-000021
- 2024-01-28 liabilities: us-gaap:Liabilities; filed 2025-02-26; accession 0001045810-25-000023
- 2024-01-28 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2026-02-25; accession 0001045810-26-000021
- 2024-01-28 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2024-01-28 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets; filed derived or not found; accession derived or not found
- 2024-01-28 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2024-01-28 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2025-01-26 revenue: us-gaap:Revenues; filed 2026-02-25; accession 0001045810-26-000021
- 2025-01-26 net_income: us-gaap:NetIncomeLoss; filed 2026-02-25; accession 0001045810-26-000021
- 2025-01-26 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-02-25; accession 0001045810-26-000021
- 2025-01-26 capital_spending: us-gaap:PaymentsToAcquireProductiveAssets; filed 2026-02-25; accession 0001045810-26-000021
- 2025-01-26 equity: us-gaap:StockholdersEquity; filed 2026-02-25; accession 0001045810-26-000021
- 2025-01-26 liabilities: us-gaap:Liabilities; filed 2026-02-25; accession 0001045810-26-000021
- 2025-01-26 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2026-02-25; accession 0001045810-26-000021
- 2025-01-26 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2025-01-26 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets; filed derived or not found; accession derived or not found
- 2025-01-26 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2025-01-26 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
- 2026-01-25 revenue: us-gaap:Revenues; filed 2026-02-25; accession 0001045810-26-000021
- 2026-01-25 net_income: us-gaap:NetIncomeLoss; filed 2026-02-25; accession 0001045810-26-000021
- 2026-01-25 operating_cash_flow: us-gaap:NetCashProvidedByUsedInOperatingActivities; filed 2026-02-25; accession 0001045810-26-000021
- 2026-01-25 capital_spending: us-gaap:PaymentsToAcquireProductiveAssets; filed 2026-02-25; accession 0001045810-26-000021
- 2026-01-25 equity: us-gaap:StockholdersEquity; filed 2026-02-25; accession 0001045810-26-000021
- 2026-01-25 liabilities: us-gaap:Liabilities; filed 2026-02-25; accession 0001045810-26-000021
- 2026-01-25 research_and_development: us-gaap:ResearchAndDevelopmentExpense; filed 2026-02-25; accession 0001045810-26-000021
- 2026-01-25 roe: derived: NetIncomeLoss / StockholdersEquity; filed derived or not found; accession derived or not found
- 2026-01-25 owner_earnings: derived: us-gaap:NetCashProvidedByUsedInOperatingActivities - us-gaap:PaymentsToAcquireProductiveAssets; filed derived or not found; accession derived or not found
- 2026-01-25 liabilities_to_equity: derived: Liabilities / StockholdersEquity; filed derived or not found; accession derived or not found
- 2026-01-25 rd_to_revenue: derived: ResearchAndDevelopmentExpense / revenue; filed derived or not found; accession derived or not found
