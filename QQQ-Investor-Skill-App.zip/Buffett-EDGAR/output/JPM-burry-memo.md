# Burry: pass

AI simulation; not an authentic investor statement. Business quality only.

I would pass under these classroom rules. Latest operating cash flow is -147,782 million USD against net income of 57,048 million USD, and latest liabilities/equity is 11.21, above the ceiling of 2. Both checks fail. This warrants further investigation, not an accusation of manipulation. A bank needs industry-specific analysis of funding, liquidity, credit losses and regulatory capital before these generic ratios can support an investment conclusion.
