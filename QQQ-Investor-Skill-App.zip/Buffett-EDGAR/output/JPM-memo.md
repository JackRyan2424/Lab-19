# JPMorgan — watch it

*AI simulation in a Buffett-inspired voice; not a statement by Warren Buffett. Business quality only; no price assessment.*

I would **watch it**. Net income is $57,048 million and ROE is 15.7% for the fiscal year ending 2025-12-31. But the consistent-return check fails: ROE was 12.9% on 2022-12-31, below the 15% hurdle.

I cannot judge owner earnings. Capital spending is not found under the permitted tags in these annual filings, so owner earnings are not found and the owner-earnings checks are not known. I will not treat a missing expenditure as zero or substitute net income for cash available to owners.

The printed results leave too much unanswered for an ownership verdict from this screen. They do not establish a durable moat, management quality or the safety of the balance sheet. I would investigate those questions and seek an appropriate understanding of the business's cash requirements before reaching a stronger judgment. This is a limit of the available evidence, not proof that the business is poor.
