@echo off
cd /d "%~dp0.."
py -m streamlit run Buffett-EDGAR/app.py --server.port 8504 --server.address localhost
