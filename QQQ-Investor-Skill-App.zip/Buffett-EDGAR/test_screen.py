import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "buffett_skill" / "scripts"))
from edgar import build_report, year_row, checks, unsupported_numbers, TAGS

def fixture():
    facts = {"entityName": "Synthetic test only", "facts": {"us-gaap": {}}}
    for metric, tags in TAGS.items():
        values = []
        for year in range(2021, 2026):
            fact = {"end": f"{year}-12-31", "form": "10-K", "filed": f"{year+1}-02-01",
                    "accn": str(year), "val": {"equity": 100, "net_income": 20, "operating_cash_flow": year-2000,
                                               "capital_spending": 5}.get(metric, 50)}
            if metric not in ("equity", "liabilities"):
                fact["start"] = f"{year}-01-01"
            values.append(fact)
        facts["facts"]["us-gaap"][tags[0]] = {"units": {"USD": values}}
    return facts

class Rules(unittest.TestCase):
    def test_latest_annual_10k_wins(self):
        f = fixture()
        values = f["facts"]["us-gaap"][TAGS["net_income"][0]]["units"]["USD"]
        values += [dict(values[-1], val=30, filed="2027-01-01"),
                   dict(values[-1], val=999, filed="2028-01-01", form="10-Q"),
                   dict(values[-1], val=888, filed="2029-01-01", start="2025-10-01")]
        self.assertEqual(year_row(f, "2025-12-31")["net_income"]["value"], 30)

    def test_missing_and_nonpositive(self):
        f = fixture()
        del f["facts"]["us-gaap"][TAGS["capital_spending"][0]]
        f["facts"]["us-gaap"]["StockholdersEquity"]["units"]["USD"][-1]["val"] = 0
        report = build_report(f, "TEST")
        row = report["rows"][-1]
        self.assertEqual(row["owner_earnings"]["value"], "not found")
        self.assertEqual(row["roe"]["value"], "not known")
        self.assertEqual(row["liabilities_to_equity"]["value"], "not known")
        self.assertTrue(all(v == "not known" for v in report["checks"].values()))

    def test_priority_and_fallback(self):
        f = fixture()
        original = f["facts"]["us-gaap"][TAGS["revenue"][0]]
        f["facts"]["us-gaap"]["Revenues"] = {"units": {"USD": [dict(original["units"]["USD"][-1], val=999)]}}
        self.assertEqual(year_row(f, "2025-12-31")["revenue"]["value"], 50)
        del f["facts"]["us-gaap"][TAGS["revenue"][0]]
        self.assertEqual(year_row(f, "2025-12-31")["revenue"]["value"], 999)

    def test_checks_and_audit(self):
        report = build_report(fixture(), "TEST")
        self.assertTrue(all(v == "pass" for v in report["checks"].values()))
        self.assertEqual(unsupported_numbers("ROE 20.0%", report), [])
        self.assertEqual(unsupported_numbers("ROE 40.0%", report)[0]["number"], "40.0%")
        self.assertTrue(unsupported_numbers("ROE -20.0%", report))
        self.assertTrue(unsupported_numbers("99.9", report))

    def test_streamlit_empty_start(self):
        from streamlit.testing.v1 import AppTest
        app = AppTest.from_file(str(ROOT / "Buffett-EDGAR" / "app.py")).run(timeout=30)
        self.assertEqual(len(app.exception), 0)

if __name__ == "__main__":
    unittest.main()
