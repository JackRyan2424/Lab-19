"""Compare live reports to the user's classroom answer, never use it as app data."""
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "buffett_skill" / "scripts"))
from edgar import unsupported_numbers

EXPECTED = [
    ("2022-08-28", 226954, 5844, 7392, 3891, 20642, 28.3, 3501),
    ("2023-09-03", 242290, 6292, 11068, 4323, 25058, 25.1, 6745),
    ("2024-09-01", 254453, 7367, 11339, 4710, 23622, 31.2, 6629),
    ("2025-08-31", 275235, 8099, 13335, 5498, 29164, 27.8, 7837),
    ("2026-08-30", 303154, 9226, 15817, 6435, 35803, 25.8, 9382),
]
METRICS = ["revenue", "net_income", "operating_cash_flow", "capital_spending", "equity", "roe", "owner_earnings"]
output = Path(__file__).resolve().parent / "output"
messages, errors = [], []
for ticker in ("COST", "JPM"):
    path = output / f"{ticker}-report.json"
    if not path.exists():
        errors.append(f"{ticker}: live report not yet downloaded")
        continue
    report = json.loads(path.read_text(encoding="utf-8"))
    if ticker == "COST":
        rows = {r["fiscal_year_end"]: r for r in report["rows"]}
        for end, *expected in EXPECTED:
            if end not in rows:
                errors.append(f"COST {end}: absent from SEC report; do not fabricate it")
                continue
            for metric, answer in zip(METRICS, expected):
                raw = rows[end][metric]["value"]
                actual = round(raw * 100, 1) if metric == "roe" and isinstance(raw, (int, float)) else raw / 1_000_000 if isinstance(raw, (int, float)) else raw
                if actual != answer:
                    errors.append(f"COST {end} {metric}: SEC {actual}, classroom {answer}")
        if not all(v == "pass" for v in report["checks"].values()):
            errors.append("COST: not all checks pass")
        if not unsupported_numbers("ROE 40.0%", report):
            errors.append("COST: fabricated percentage was not flagged")
    else:
        for row in report["rows"]:
            for metric in ("capital_spending", "owner_earnings"):
                if row[metric]["value"] != "not found":
                    errors.append(f"JPM {row['fiscal_year_end']} {metric}: SEC now supplies a value; investigate against assignment")
        for name, value in report["checks"].items():
            if name.startswith("Owner earnings") and value != "not known":
                errors.append(f"JPM {name}: expected not known, received {value}")
    messages.append(f"{ticker}: checked SEC snapshot {report['facts_sha256']}")
result = "\n".join(messages + errors + (["All live comparisons passed."] if not errors else ["Live verification is incomplete or has discrepancies."]))
(output / "verification.txt").write_text(result, encoding="utf-8")
print(result)
raise SystemExit(bool(errors))
