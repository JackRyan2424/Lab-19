"""Exercise the actual app with saved SEC reports, including the hand-edit probe."""
from pathlib import Path
import unittest
from streamlit.testing.v1 import AppTest

class LiveApp(unittest.TestCase):
    def test_cost_memo_and_hand_typed_number(self):
        app = AppTest.from_file(str(Path(__file__).with_name("app.py"))).run(timeout=30)
        self.assertFalse(app.exception)
        self.assertTrue(app.text_area[0].value.startswith("# Costco"))
        self.assertEqual(len(app.dataframe), 2)
        app.text_area[0].set_value(app.text_area[0].value + "\nROE was 40.0%.").run(timeout=30)
        self.assertFalse(app.exception)
        self.assertTrue(any("40.0%" in error.value for error in app.error))

    def test_jpm_saved_view(self):
        app = AppTest.from_file(str(Path(__file__).with_name("app.py"))).run(timeout=30)
        app.text_input[0].set_value("JPM")
        next(button for button in app.button if button.label == "View saved report").click().run(timeout=30)
        self.assertFalse(app.exception)
        self.assertIn("cannot judge owner earnings", app.text_area[0].value)
        self.assertFalse(app.error)

if __name__ == "__main__":
    unittest.main()
