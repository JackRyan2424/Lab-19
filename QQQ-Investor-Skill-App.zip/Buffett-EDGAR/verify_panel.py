"""Verify classroom answer, honest gaps, audit coverage and app interactions."""
import copy
import json
from pathlib import Path
import unittest
from panel import OUTPUT, evaluate, audit, SLUGS
from build_panel_submission import main as build_submission
from expert_format import empty_structure, claim_values

def report(ticker):
    return json.loads((OUTPUT/f'{ticker}-report.json').read_text(encoding='utf-8'))

class PanelTests(unittest.TestCase):
    def test_original_formats_and_json_audits(self):
        def field_paths(value, prefix=''):
            paths = set()
            if isinstance(value, dict):
                for key, child in value.items():
                    path = prefix + '/' + key
                    paths.add(path)
                    paths.update(field_paths(child, path))
            return paths
        for ticker in ('COST', 'AAPL'):
            for slug in SLUGS:
                data = json.loads((OUTPUT/f'{ticker}-{slug}-analysis.json').read_text(encoding='utf-8'))
                self.assertEqual(field_paths(data), field_paths(empty_structure(slug)))
                self.assertEqual(audit(claim_values(data), report(ticker)), [])
                self.assertEqual(data['confidence'], 'not known')
                self.assertIn('not known', data['forward_outlook']['price_target'])
                data['analysis'][next(iter(data['analysis']))]['reasoning'] = 'Invented claim 98765.43%'
                self.assertTrue(audit(claim_values(data), report(ticker)))

    def test_cost_known_answer_and_probe(self):
        r = report('COST')
        p = evaluate(r)
        self.assertEqual([x['Result'] for x in p['checks']], ['pass','pass','pass','fail','not known','pass','pass'])
        self.assertEqual(p['growth_display'], '7.51%')
        self.assertEqual([f"{x['liabilities_to_equity']['value']:.2f}" for x in r['rows']], ['2.11','1.75','1.96','1.64','1.49'])
        probe = evaluate(r, .05)
        self.assertEqual(probe['checks'][3]['Result'], 'pass')
        self.assertEqual(probe['checks'][4]['Result'], 'not known')

    def test_missing_and_nonpositive(self):
        r = copy.deepcopy(report('COST'))
        r['rows'][0]['revenue']['value'] = 0
        r['rows'][-1]['operating_cash_flow']['value'] = 'not found'
        r['rows'][-1]['liabilities_to_equity']['value'] = 'not known'
        p = evaluate(r)
        self.assertEqual([p['checks'][i]['Result'] for i in (3,4,5,6)], ['not known']*4)

    def test_jpm_gaps(self):
        r = report('JPM')
        self.assertEqual([x['Result'] for x in evaluate(r)['checks']], ['fail','not known','not known','fail','not known','fail','fail'])
        self.assertTrue(all(x['owner_earnings']['value'] == 'not found' for x in r['rows']))

    def test_audit_every_memo(self):
        for ticker in ('COST','AAPL'):
            for slug in SLUGS:
                memo = (OUTPUT/f'{ticker}-{slug}-memo.md').read_text(encoding='utf-8')
                self.assertEqual(audit(memo, report(ticker)), [])
                self.assertTrue(audit(memo+' Invented return 98765.43%.', report(ticker)))

    def test_app(self):
        from streamlit.testing.v1 import AppTest
        at = AppTest.from_file(str(Path(__file__).parent/'app.py'), default_timeout=25).run()
        self.assertFalse(at.exception)
        panel_editors = [x for x in at.text_area if str(x.key).startswith('panel-')]
        self.assertEqual(len(panel_editors), 3)
        for slug in SLUGS:
            editor = next(x for x in at.text_area if f'-{slug}-' in str(x.key))
            original = editor.value
            editor.set_value(original+' Invented return 98765.43%.').run()
            self.assertTrue(any('Unprinted-number flag' in x.value for x in at.error))
            at.text_area(key=editor.key).set_value(original).run()
        next(b for b in at.button if b.label == 'Known-answer check: COST').click().run()
        self.assertEqual(at.text_input(key='company_ticker').value, 'COST')
        self.assertTrue(any('7.51%' in x.value for x in at.caption))
        next(b for b in at.button if b.label == 'QQQ company: AAPL').click().run()
        self.assertFalse(at.exception)
        self.assertTrue(any('4.97%' in x.value for x in at.caption))
        self.assertFalse(at.warning)

    def test_aapl_panel(self):
        r = report('AAPL')
        self.assertEqual([x['Result'] for x in evaluate(r)['checks']], ['pass','pass','pass','fail','pass','fail','fail'])
        self.assertEqual(evaluate(r, .05)['checks'][3]['Result'], 'fail')
        self.assertEqual(evaluate(r)['growth_display'], '4.97%')
        self.assertEqual(evaluate(r)['leverage_display'], '2.61')

if __name__ == '__main__':
    build_submission()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(PanelTests)
    suite.addTests(unittest.defaultTestLoader.discover(str(Path(__file__).parent), pattern='test_screen.py'))
    import io
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    output = stream.getvalue()
    (OUTPUT/'panel-verification.txt').write_text(output, encoding='utf-8')
    print(output)
    raise SystemExit(not result.wasSuccessful())
