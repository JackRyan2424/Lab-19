"""SEC-only, deterministic Buffett classroom screen. Standard library only."""
import argparse
from datetime import date, datetime, timezone
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import re
import time
from urllib.request import Request, urlopen

TAGS = {
    "revenue": ["RevenueFromContractWithCustomerExcludingAssessedTax", "Revenues"],
    "net_income": ["NetIncomeLoss"],
    "operating_cash_flow": ["NetCashProvidedByUsedInOperatingActivities"],
    "capital_spending": ["PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"],
    "equity": ["StockholdersEquity"],
    "liabilities": ["Liabilities"],
    "research_and_development": ["ResearchAndDevelopmentExpense"],
}
METRICS = list(TAGS) + ["roe", "owner_earnings", "liabilities_to_equity", "rd_to_revenue"]
MISSING = "not found"
UNKNOWN = "not known"

def annual(fact):
    """Accept calendar and 52/53-week years, never quarters or YTD quarters."""
    if not fact.get("start") or not fact.get("end"):
        return False
    days = (date.fromisoformat(fact["end"]) - date.fromisoformat(fact["start"])).days + 1
    return 350 <= days <= 380

def candidates(facts, tag, end=None, flow=True):
    return [f for f in facts.get("facts", {}).get("us-gaap", {}).get(tag, {}).get("units", {}).get("USD", [])
            if f.get("form") == "10-K" and (end is None or f.get("end") == end)
            and (annual(f) if flow else not f.get("start"))]

def select_value(facts, metric, end):
    # Priority is applied per year. Within the chosen tag, latest filing wins.
    for tag in TAGS[metric]:
        found = candidates(facts, tag, end, metric not in ("equity", "liabilities"))
        if found:
            f = max(found, key=lambda x: (x.get("filed", ""), x.get("accn", "")))
            return {"value": f["val"], "tag": "us-gaap:" + tag,
                    "start": f.get("start"), "end": f["end"],
                    "filed": f.get("filed"), "accession": f.get("accn")}
    return {"value": MISSING, "tag": MISSING, "searched_tags": TAGS[metric]}

def year_row(facts, end):
    """Explain this function in class: select facts, preserve gaps, then compute."""
    row = {"fiscal_year_end": end}
    for metric in TAGS:
        row[metric] = select_value(facts, metric, end)
    ni, equity = row["net_income"]["value"], row["equity"]["value"]
    ocf, capex = row["operating_cash_flow"]["value"], row["capital_spending"]["value"]
    liabilities = row["liabilities"]["value"]
    rd, revenue = row["research_and_development"]["value"], row["revenue"]["value"]
    row["rd_to_revenue"] = {"value": UNKNOWN if not numeric(rd) or not numeric(revenue) or revenue <= 0 else rd / revenue,
                            "tag": "derived: ResearchAndDevelopmentExpense / revenue"}
    row["roe"] = {"value": UNKNOWN if not numeric(ni) or not numeric(equity) or equity <= 0 else ni / equity,
                  "tag": "derived: NetIncomeLoss / StockholdersEquity"}
    row["owner_earnings"] = {"value": ocf - capex if numeric(ocf) and numeric(capex) else MISSING,
                             "tag": "derived: " + row["operating_cash_flow"]["tag"] + " - " + row["capital_spending"]["tag"]}
    row["liabilities_to_equity"] = {"value": UNKNOWN if not numeric(liabilities) or not numeric(equity) or equity <= 0 else liabilities / equity,
                                    "tag": "derived: Liabilities / StockholdersEquity"}
    return row

def numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool)

def checks(rows):
    def test(metric, predicate):
        values = [r[metric]["value"] for r in rows]
        if len(values) != 5 or not all(numeric(v) for v in values):
            return UNKNOWN
        return "pass" if predicate(values) else "fail"
    return {"ROE of 15% or more every year": test("roe", lambda v: all(x >= .15 for x in v)),
            "Owner earnings positive every year": test("owner_earnings", lambda v: all(x > 0 for x in v)),
            "Owner earnings grew, first year to last": test("owner_earnings", lambda v: v[-1] > v[0])}

def build_report(facts, ticker):
    # Annual flow ends, not `fy`: comparative facts carry the filing's fiscal year.
    ends = sorted({f["end"] for metric in ("revenue", "net_income", "operating_cash_flow")
                   for tag in TAGS[metric] for f in candidates(facts, tag)})[-5:]
    if not ends:
        raise ValueError("No annual USD facts from 10-K filings found.")
    rows = [year_row(facts, end) for end in ends]
    return {"ticker": ticker, "company": facts.get("entityName", ticker), "cik": facts.get("cik"),
            "rows": rows, "checks": checks(rows),
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
            "facts_sha256": hashlib.sha256(json.dumps(facts, sort_keys=True).encode()).hexdigest()}

def display(metric, value):
    if not numeric(value):
        return value
    if metric == "roe":
        return f"{value * 100:.1f}%"
    if metric == "rd_to_revenue":
        return f"{value * 100:.2f}%"
    if metric == "liabilities_to_equity":
        return f"{value:.3f}"
    return f"{value / 1_000_000:,.6f}".rstrip("0").rstrip(".")

def table(report):
    return [{"Fiscal year end": r["fiscal_year_end"], **{m: display(m, r[m]["value"]) for m in METRICS}} for r in report["rows"]]

def printed(report):
    columns = ["Fiscal year end"] + METRICS
    lines = [f"# {report['ticker']} — {report['company']}", "Dollar amounts in USD millions; ROE in percent; liabilities/equity is a ratio.",
             "| " + " | ".join(columns) + " |", "| " + " | ".join(["---"] * len(columns)) + " |"]
    lines += ["| " + " | ".join(r[c] for c in columns) + " |" for r in table(report)]
    for name, result in report["checks"].items():
        lines.append(f"- {name}: {result}")
    lines.append("\nTags and provenance (derived metrics have no standalone XBRL tag):")
    for row in report["rows"]:
        for metric in METRICS:
            f = row[metric]
            lines.append(f"- {row['fiscal_year_end']} {metric}: {f['tag']}; filed {f.get('filed', 'derived or not found')}; accession {f.get('accession', 'derived or not found')}")
    return "\n".join(lines) + "\n"

# Literal numeric claims: preserve percent units, signs and whole ISO dates.
NUMBER = re.compile(r"\d{4}-\d{2}-\d{2}|[-+−]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?(?:[eE][-+]?\d+)?\s*%?")
def number_key(token):
    token = token.strip().replace("−", "-")
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", token):
        return ("date", token)
    return ("percent" if token.endswith("%") else "number", Decimal(token.rstrip("%").strip().replace(",", "")))

def unsupported_numbers(memo, report):
    # Only displayed financial cells, fiscal dates, and the check threshold qualify.
    # Accession numbers and retrieval timestamps cannot authorize financial claims.
    cells = [v for row in table(report) for v in row.values()] + ["15%"]
    allowed = {number_key(m.group()) for cell in cells for m in NUMBER.finditer(cell)}
    return [{"number": m.group().strip(), "line": memo[:m.start()].count("\n") + 1}
            for m in NUMBER.finditer(memo) if number_key(m.group()) not in allowed]

def download(url, user_agent):
    if not re.search(r"\S+@\S+\.\S+", user_agent) or len(user_agent.split()) < 2:
        raise ValueError("Set SEC_USER_AGENT to your name and real contact email.")
    time.sleep(.2)
    with urlopen(Request(url, headers={"User-Agent": user_agent, "Accept": "application/json"}), timeout=45) as response:
        return json.load(response)

def fetch(ticker, user_agent, output):
    ticker = ticker.strip().upper()
    if not re.fullmatch(r"[A-Z][A-Z0-9.-]{0,14}", ticker):
        raise ValueError("Enter a valid ticker.")
    tickers = download("https://www.sec.gov/files/company_tickers.json", user_agent)
    company = next((v for v in tickers.values() if v["ticker"].upper() == ticker), None)
    if company is None:
        raise ValueError(f"Ticker {ticker} not found in SEC ticker mapping.")
    url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{int(company['cik_str']):010d}.json"
    facts = download(url, user_agent)
    report = build_report(facts, ticker)
    report["source_url"] = url
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    (output / f"{ticker}-facts.json").write_text(json.dumps(facts), encoding="utf-8")
    (output / f"{ticker}-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (output / f"{ticker}-numbers.md").write_text(printed(report), encoding="utf-8")
    return report

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("ticker")
    parser.add_argument("--output", default="Buffett-EDGAR/output")
    parser.add_argument("--user-agent", default=os.environ.get("SEC_USER_AGENT", ""))
    parser.add_argument("--audit-memo")
    args = parser.parse_args()
    if args.audit_memo:
        report = json.loads((Path(args.output) / f"{args.ticker.upper()}-report.json").read_text(encoding="utf-8"))
        errors = unsupported_numbers(Path(args.audit_memo).read_text(encoding="utf-8"), report)
        print(json.dumps(errors, indent=2))
        raise SystemExit(bool(errors))
    print(printed(fetch(args.ticker, args.user_agent, args.output)))

if __name__ == "__main__":
    main()
