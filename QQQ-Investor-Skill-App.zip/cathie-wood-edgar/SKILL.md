---
name: cathie-wood-edgar
description: Apply the classroom Cathie Wood-inspired growth and research screen to the shared SEC annual facts and write an audited business-quality memo.
---

Use the growth and innovation lens from [FAskills Cathie Wood](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/cathie_wood.md). This is a narrow classroom adaptation, not her complete strategy or her actual opinion. Do not install its providers or use forecasts, prices, or valuation.

From the workspace run `python Buffett-EDGAR/panel.py TICKER` on the saved SEC snapshot. Read the printed evidence before writing. The shared code preserves the Buffett selection rules and adds only ResearchAndDevelopmentExpense and Liabilities. All investors use the same facts and fiscal periods.

The default growth threshold is 15%. Code in `Buffett-EDGAR/panel.py` tests (last revenue / first revenue) ** (1/4) - 1 against that threshold across five years, and latest ResearchAndDevelopmentExpense / revenue against 5%. Missing inputs stay not known; absent R&D is not zero. For the probe, call `evaluate(report, .05)` and compare with `evaluate(report, .15)` on identical facts. Keep 15% for the submitted baseline because this lens is intended to distinguish high growth, not to make the example pass.

Write an explicitly labeled AI simulation in first person from printed numbers only. Choose own the business, watch it, or pass as a qualitative business-screen verdict. Explain that historical growth and reported R&D cannot establish disruptive innovation. Save `Buffett-EDGAR/output/TICKER-cathie-wood-memo.md`. Under the memo state the retained threshold and why. Run `panel.audit` and review metric associations; save `panel.binding(report)` in the corresponding `TICKER-cathie-wood-memo-source.txt` only after review. The app flags unsupported numbers in every memo and stale bindings separately.

## FAskills format used in the app

Read [the pinned original file](references/faskills-source.md), especially its Required Output Format and Voice & Tone. Preserve its JSON field names and nesting. `Buffett-EDGAR/expert_format.py` extracts that structure and renders the investor-specific analysis sections in the memo. Keep the assignment's code checks and printed-number-only rule. Unsupported forecasts, prices, confidence scores, qualitative scores, actual investor holdings and boolean judgments remain `not known`; absent raw facts remain `not found`. This explicitly adapts upstream value types rather than inventing values to satisfy the template. Signals describe business-screen fit, not stock-return predictions. Label all output as an AI simulation.

Save both the formatted memo and `TICKER-INVESTOR-analysis.json`. Audit all JSON value leaves with `panel.audit(expert_format.claim_values(data), report)` as well as the memo. Do not audit digits in field names as financial claims. Save the source URL, file hash and report binding in the format-source sidecar after review. The app exposes the original source and structured analysis alongside each memo.
