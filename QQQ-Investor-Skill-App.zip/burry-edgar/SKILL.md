---
name: burry-edgar
description: Apply the classroom Burry-inspired cash-backing and liabilities screen to shared SEC annual facts and write an audited skeptical memo.
---

Use the accounting-quality and downside lens from [FAskills Michael Burry](https://github.com/CinderZhang/FAskills/blob/main/financial-researcher/experts/michael_burry.md). This is a classroom adaptation and AI simulation, not Burry's actual view. Do not install providers or use prices, forecasts, short recommendations, or valuation.

Run `python Buffett-EDGAR/panel.py TICKER` from the workspace and read its printed evidence. `evaluate` in that script tests operating cash flow >= net income in every selected year and latest Liabilities / StockholdersEquity <= 2. Missing source values remain not found; checks with missing inputs and ratios with nonpositive equity remain not known. All investors read the same raw SEC snapshot and use the existing Buffett fiscal-year and tag selection rules.

Write a first-person skeptical memo, explicitly labeled an AI simulation, using only printed financial numbers. Choose own the business, watch it, or pass as a business-screen verdict. Separate a failed check from evidence of fraud; these ratios cannot establish accounting manipulation. Consider industry limitations, especially deposit-funded banks, and describe a bear case as a hypothesis. Save `Buffett-EDGAR/output/TICKER-burry-memo.md`. Run `panel.audit`, review numeric meaning, and then save `panel.binding(report)` to `TICKER-burry-memo-source.txt`. Do not automatically infer an investment verdict from the check count.

## FAskills format used in the app

Read [the pinned original file](references/faskills-source.md), especially its Required Output Format and Voice & Tone. Preserve its JSON field names and nesting. `Buffett-EDGAR/expert_format.py` extracts that structure and renders the investor-specific analysis sections in the memo. Keep the assignment's code checks and printed-number-only rule. Unsupported forecasts, prices, confidence scores, qualitative scores, actual investor holdings and boolean judgments remain `not known`; absent raw facts remain `not found`. This explicitly adapts upstream value types rather than inventing values to satisfy the template. Signals describe business-screen fit, not stock-return predictions. Label all output as an AI simulation.

Save both the formatted memo and `TICKER-INVESTOR-analysis.json`. Audit all JSON value leaves with `panel.audit(expert_format.claim_values(data), report)` as well as the memo. Do not audit digits in field names as financial claims. Save the source URL, file hash and report binding in the format-source sidecar after review. The app exposes the original source and structured analysis alongside each memo.
